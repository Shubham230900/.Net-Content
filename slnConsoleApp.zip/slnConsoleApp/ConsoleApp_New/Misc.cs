﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_New
{

	public interface ITestNew
	{
		void Hide();
	}

	internal interface ITest
	{
		void Show();

		public void Print()    //Default Interface Methods
		{
			Console.WriteLine("Hello!");
		}

		void SuperSecretMethod();
	}

	public abstract class Demo
	{
		public abstract void Show();

		public void Print()    //Default Interface Methods
		{
			Console.WriteLine("Hello!");
		}
	}


	public class ClassA : Demo, ITest
	{
		void ITest.Show()
		{
			Console.WriteLine("");
		}

		public void Print()
		{
			Console.WriteLine("");
		}

		public override void Show()
		{
			Console.WriteLine("");
		}

		void ITest.SuperSecretMethod()
		{
			Console.WriteLine("My Secret Key");
		}
	}



	public class Teacher
	{

		public void Demo()
		{
			//Invalid - Can't create instance of Interface
			//ClassA obj = new ITest();
			//ITest ObjI = new ITest();

			ClassA objA = new ClassA();
			objA.Show();
			objA.Print();           //will call classA's function
									//objA.SuperSecretMethod();

			ITest objI = new ClassA();
			objI.Show();
			objI.Print();           //will call ITest's default function
			objI.SuperSecretMethod();


			Demo objD = new ClassA();
			objD.Show();    //Demo
			objD.Print();   //Demo


		}



		//property with init setter can't be assignes any value after initilization.
		public int Id { get; init; }        //<----- property with init setter

		public string Name { get; set; }
		public string Address { get; set; }

	}

}


namespace MyNamespace
{


	public class MumbaiTeacher
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
	}



}