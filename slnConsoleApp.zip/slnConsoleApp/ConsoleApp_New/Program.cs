﻿using CommonLibrary;
using CommonLibrary.CSharp_Basic;
using System.Reflection.Metadata;
using static CommonLibrary.CSharp_Basic.APublicClassToDemoOtherAccessModifier;
using ConsoleApp_Old;
using ConsoleApp_New;
using CommonLibrary.OOPs;
using CommonLibrary.OOPs.Inheritance;
using CommonLibrary.OOPs.Polymorphism;

HelperClass obj = new HelperClass();
obj.ShowMsg("Hello! World");

Operator objOp = new Operator();
//objOp.DemoOperator();

//objOp.DemoArray();

objOp.DemoOptionalParameter(20);

objOp.DemoOptionalParameter(20, 25);

objOp.DemoOptionalParameter("Tim", "Cook");

objOp.DemoOptionalParameter("Lily", "Cook", "Mrs.");

Out_Ref_Keyword objOutRef = new Out_Ref_Keyword();
objOutRef.Demo();

DataType_Conversion objDataType = new DataType_Conversion();
objDataType.DemoMethod();


Console.WriteLine("-------------- Class Object Constructor Properties Demo---------------------");

Class_Object ObjClassObject_One = new Class_Object();
//Execution flow:
//Static Ctor
//Global Variables
//Default Ctor

Console.WriteLine("-------------------------- Global Variable ------------------------------------");

//already set within the class - Global Variable
Console.WriteLine(ObjClassObject_One.a);
Console.WriteLine(ObjClassObject_One.str);


//Important Notes:
//below is a private global variable of the class so that's y it is not accessible here.
//Console.WriteLine(ObjClassObject_One.privateGlobalVariable);
//ObjClassObject_One.privateGlobalVariable = 654;


ObjClassObject_One.a = 100;
ObjClassObject_One.str = "hello";

Console.WriteLine(ObjClassObject_One.a);
Console.WriteLine(ObjClassObject_One.str);

Console.WriteLine("-------------------------- Properties ------------------------------------");

//Getting the value from the property
Console.WriteLine(ObjClassObject_One.MyProperty);
//Setting the value from the property
ObjClassObject_One.MyProperty = 345678;


//Use property 
ObjClassObject_One.FirstName = "FirstName";
ObjClassObject_One.LastName = "LastName";

Console.WriteLine(ObjClassObject_One.FirstName + " " + ObjClassObject_One.LastName);

Console.WriteLine(ObjClassObject_One.FullName);

ObjClassObject_One.FullName = "Tatya Bichhu"; //<------- setter in play
ObjClassObject_One.DemoClassObjectMethod_One();

Console.WriteLine(ObjClassObject_One.FullName);

Console.WriteLine(ObjClassObject_One.Name);
Console.WriteLine(ObjClassObject_One.ID);

ObjClassObject_One.Name = "Ankit";
ObjClassObject_One.ID = 100;

//Get Property
Console.WriteLine(ObjClassObject_One.Name_Not_To_Be_Set);

//Important Notes:
//We can't set a value to the below property as it does not have a Setter function and only has get
//ObjClassObject_One.Name_Not_To_Be_Set = "uyfgkjbjbjkjkjgjkgkj";

Console.WriteLine(ObjClassObject_One.Name);
Console.WriteLine(ObjClassObject_One.ID);

Console.WriteLine("------------------------- First Object Method Calling -------------------------------------");

ObjClassObject_One.DemoClassObjectMethod_One();

ObjClassObject_One.DemoClassObjectMethod_Two();


Console.WriteLine("------------------------- New Object Creation -------------------------------------");

Class_Object ObjClassObject_Two = new Class_Object();

Console.WriteLine("------------------------- Second Object Method Calling -------------------------------------");

ObjClassObject_Two.DemoClassObjectMethod_One();

ObjClassObject_Two.DemoClassObjectMethod_Two();



//Console.WriteLine("------------------------- Third Object Using Method Calling -------------------------------------");

Class_Object ObjClassObject_Parametrize_One = new Class_Object(234567);
Class_Object ObjClassObject_Parametrize_Two = new Class_Object("234567");
Class_Object ObjClassObject_Parametrize_Three = new Class_Object(9689, "234567");


Console.WriteLine(" ------------- Indexer Demo ------------------");

Class_Indexer objIndex = new Class_Indexer();

//Example of Indexers
objIndex[0] = "Shubham";
objIndex[1] = "Mayur";
objIndex[2] = "Subha";
objIndex[5] = "Shub";

//Example of Array as a class property
objIndex.arr = new string[10];
objIndex.arr[0] = "1";
objIndex.arr[1] = "2";
objIndex.arr[2] = "3";
objIndex.arr[3] = "4";

//print indexers value using for loop
for (int i = 0; i < 10; i++)
{
	Console.WriteLine(objIndex[i]);
}

//foreach (var row in objIndex) 
//{ 
////Not able to run foreach on the objIndex as it is not a collection
//}

Console.WriteLine("---------------------- Access Specifier ---------------------");

//---Internal class can't be accessed outside in other project
//ClassWithoutAnyAccessSpecifier classWithoutAnyAccessSpecifier = new ClassWithoutAnyAccessSpecifier();	//not working
//ClassWhichIsInternal classWhichIsInternal = new ClassWhichIsInternal();	//not working

ClassWhichIsPublic classWhichIsPublic = new ClassWhichIsPublic();   //works fine

NonStaticClass.LogUserActivity("TesT");

Console.WriteLine("---------- Access Specifier - with Outer Class ------------");


//AClassWithoutAnyAccessSpecifier classWithoutAnyAccessSpecifier = new AClassWithoutAnyAccessSpecifier();

//AnInternalClass anInternalClass = new AnInternalClass();

APublicClass aPublicClass = new APublicClass();

//APrivateClass aPrivateClass = new APrivateClass();

//AProtectedClass aProtectedClass = new AProtectedClass();

//AProtectedInternalClass aProtectedInternalClass = new AProtectedInternalClass();


//CommonClassDemo commonClassDemo = new CommonClassDemo();


Console.WriteLine("---------- Static Keyword ------------");

//Can't create an instance of the static class
//MyStaticClass myStaticClass = new MyStaticClass();


Console.WriteLine(MyStaticClass.Name);


//This is how you call functions of a static class. As we can't create the obj explicity and the CLR will create and keep it when the application starts for the first time.
MyStaticClass.MyFunction();

//Below is not allowed for static methods......as you can't access static methods with the reference/object of the class.
NonStaticClass nonStaticClass = new NonStaticClass();
//nonStaticClass.AStaticMethod();

//Static method is called using the name of the class.
NonStaticClass.AStaticMethod();

//Static property
ADifferntNonStaticClass.Id += 1;


Console.WriteLine(ADifferntNonStaticClass.Id);


//Below is not allowed
ADifferntNonStaticClass aDifferntNonStaticClass = new ADifferntNonStaticClass();
//aDifferntNonStaticClass.Id

Console.WriteLine(ADifferntNonStaticClass.Id);

NonStaticClass.LogUserActivity("ertyuiop");

#region CommnetedSection



//objDataType.ShowMsg("qwerty");


//public interface ITestTwo
//{
//	void Show()
//	{
//		Console.WriteLine("Hello");
//	}

//	void Hide();
//}

//public interface ITestOne
//{
//	void Show()
//	{
//		Console.WriteLine("Hello");
//	}

//	void Hide();
//}

//public class Parent
//{

//}

//public class Test : Parent, ITestOne, ITestTwo
//{

//	public void Hide()
//	{

//	}

//	public void Demo() 
//	{

//		ITestOne obj = new Test();


//	}


//}

#endregion


Console.WriteLine("---------- Namespace Keyword ------------");

Red.MyClassTwo classTwo = new Red.MyClassTwo();

Red.Red.MyClassTwo myClassTwo = new Red.Red.MyClassTwo();


Console.WriteLine("---------- Init Setter Keyword ------------");

Student studentOne = new Student();
studentOne.Id = 1;
studentOne.Name = "Ankit";
studentOne.Address = "Ankit's Address";

Student studentTwo = new Student(2);
studentTwo.Name = "Aman";
studentTwo.Address = "Aman's Address";


//Teacher teacher = new Teacher() { Id = 1 };
//teacher.Id = 276;			// we can't assign value to properties with Init setter.


MethodOverloading methodOverloading = new MethodOverloading();
methodOverloading.MyMethod("Ankit");

Parent parent = new Parent();
Console.WriteLine(parent.Id);
//parent.ShowMsg();

Child child = new Child();
Console.WriteLine(child.Id);
//child.ShowMsg();
//child.Print();


//Console.WriteLine(parent.BragAboutTheProperty());	//

//Child child = new Child();
//Console.WriteLine(child.BragAboutTheProperty()); //
//Console.WriteLine(child.BuildMoreProperty());

//Child childParam = new Child(100);


Console.WriteLine("---------- Object Creation With Inheritance ------------");

ParentClass parentClass = new ParentClass();

ChildClass childClass = new ChildClass();

//Most Important
//ChildClass childClassOne = new ParentClass();  //<----- Invalid ----- Compile Time Error
//ChildClass childClassOne = (ChildClass) new ParentClass();  //<----- Invalid ----- Runtime Error

ParentClass parentClassOne = new ChildClass();

Console.WriteLine("---------- Method Overriding ------------");

//Parent class can only access its own members and properties
MyClassOne obj1 = new MyClassOne();
//obj1.Show();		//Will always run from MyClassOne as it is only present in MyClassOne
obj1.Print();
obj1.Show("Hiiiiiiiiiiiii");

MyClassTwo obj2 = new MyClassTwo();
//obj2.Show();
obj2.Print();
obj2.Show("Hi! How are you?");

MyClassOne obj3 = new MyClassTwo(); //-> Parent (MyClassOne) + Child (MyClassTwo) both instance
									//obj3.Show();
obj3.Print();
obj3.Show("Hi! How are you?");


#region ImportantConcept

//Compile Time Error
//MyClassTwo obj4 = new MyClassOne(); //-> Parent (MyClassOne) Instance  

//Run Time error
//MyClassTwo obj5 = (MyClassTwo) new MyClassOne(); //-> Parent (MyClassOne) Instance  

#endregion



Console.WriteLine("// --------- Abstract Class -------------- //");

//*** We can't instantiated an abstract class
//Abstract_ParentClass abstract_ParentClass = new Abstract_ParentClass();

//Invoking the below class will also invoke the constructor of the abstract class
ANonAbstract_ChildClass aNonAbstract_ChildClass = new ANonAbstract_ChildClass();

aNonAbstract_ChildClass.Common_NonAbstactMethod();  //called from abstract class .. as it was declared in abstract class only
aNonAbstract_ChildClass.Calculate();

aNonAbstract_ChildClass.ShowMessage("Hiiiiiiiiiii");

// ---------------------------- -------------------------------- //

CommonLibrary.CSharp_Basic.Inheritance.ParentClass objParentClass = new CommonLibrary.CSharp_Basic.Inheritance.ParentClass();

CommonLibrary.CSharp_Basic.Inheritance.ChildClass objChildClass = new CommonLibrary.CSharp_Basic.Inheritance.ChildClass();

CommonLibrary.CSharp_Basic.Inheritance.ParentClass objParentClassNew = new CommonLibrary.CSharp_Basic.Inheritance.ChildClass();

// ----------------------------------- Interface Demo ------------------------------------ //

Test objTest = new Test();

objTest.Show();
objTest.Show("xyz");    //implicitly calling interface

ITestOne testOne = new Test();
testOne.Show("abc");

ITestTwo testTwo = new Test();
testTwo.Show("abc");


//Explicit interface function calling

//Demo demo = new Demo();
//demo.Print("Hello"); //implicit interface method calling
//demo.Show(""); can't call explicit interface method using class object


//IDemo objIDemo = new Demo();
//objIDemo.Show("Hiiiiiiiiii");   //Explicit interface method calling using object of type interface


//----------------------------- Error and Exception Handling ---------------------------------- //

//If you uncomment and execute below it will throw an error/exception and will stop the application execution.
//ExceptionHandling.Problem();

//ExceptionHandling.Solution_Basic();

//ExceptionHandling.Solution_Advance();

ExceptionHandling.NormalMethod();

ExceptionHandling.MultipleException(null);


CustomExceptionImplementation.CheckMobileNumber("+917737703521");

// ---------------------- Copy Constructor ---------------------------- //

//StudentClass objStudentClassOne = new StudentClass();   //Default values

//Console.WriteLine("objStudentClassOne Initial/Default Values");
//Console.WriteLine(objStudentClassOne.Id);
//Console.WriteLine(objStudentClassOne.Name);
//Console.WriteLine(objStudentClassOne.Address);

//StudentClass objStudentClassTwo = objStudentClassOne;
//objStudentClassTwo.Id = 100;
//objStudentClassTwo.Name = "Test 100";
//objStudentClassTwo.Address = "Test Addresss 100";

//Console.WriteLine("objStudentClassOne Values after we assign value to objStudentClassTwo");
//Console.WriteLine(objStudentClassOne.Id);
//Console.WriteLine(objStudentClassOne.Name);
//Console.WriteLine(objStudentClassOne.Address);

//Console.WriteLine("objStudentClassTwo Values");
//Console.WriteLine(objStudentClassTwo.Id);
//Console.WriteLine(objStudentClassTwo.Name);
//Console.WriteLine(objStudentClassTwo.Address);


//Copy Constructor
StudentClass objStudentClassThree = new StudentClass();

objStudentClassThree.Id = 1000000001;
objStudentClassThree.Name = "Test 100000000000001";
objStudentClassThree.Address = "Test Addresss 1000000000000000000001";

Console.WriteLine("objStudentClassThree Values after we initialize objStudentClassThree with a copy ctor");
Console.WriteLine(objStudentClassThree.Id);
Console.WriteLine(objStudentClassThree.Name);
Console.WriteLine(objStudentClassThree.Address);

//Console.WriteLine("objStudentClassOne Values");
//Console.WriteLine(objStudentClassOne.Id);
//Console.WriteLine(objStudentClassOne.Name);
//Console.WriteLine(objStudentClassOne.Address);

//Console.WriteLine("objStudentClassTwo Values");
//Console.WriteLine(objStudentClassTwo.Id);
//Console.WriteLine(objStudentClassTwo.Name);
//Console.WriteLine(objStudentClassTwo.Address);


Address objAddress = new Address();
objAddress.Id = 1;
objAddress.CityName = "Jaipur";
objAddress.HouseNumber = "S4B";

CommonLibrary.CSharp_Basic.Teacher teacherObj = new CommonLibrary.CSharp_Basic.Teacher();
teacherObj.Id = 1;
teacherObj.Name = "Ankit";
teacherObj.Address = objAddress; //new Address() { Id = 1, CityName = "Jaipur", HouseNumber = "S4B" };

Console.WriteLine(teacherObj.Id);

Console.WriteLine(" ------------------------- File System---------------------------------------- ");

FileSystem.DemoFileSystem();

Console.WriteLine(" ------------------------- Boxing n Unboxing ---------------------------------------- ");

Boxing_UnBoxing.Demo_Boxing_UnBoxing();

Console.WriteLine(" ------------------------- Parse n TryParse ---------------------------------------- ");

Parse_TryParse.Demo_Parse_TryParse();

Console.WriteLine(" ------------------------- Anonymous Type ---------------------------------------- ");

AnonymousType.DemoAnonymousType();

Console.WriteLine(" ------------------------- Delegate ---------------------------------------- ");

ToDo_Delegate.DemoDelegate();

UseOfDelegate.DemoDelegateUse("Circle", 4);

UseOfDelegate.DemoDelegateUse("Square", 4);

UseOfDelegate.DemoDelegateUse("Triangle", 4, 5, 7);

UseOfDelegate.DemoDelegateUse("Rectangle", 14, 7);

CommonLibrary.CSharp_Basic.MulticastDelegate.DemoMulticastDelegate();


TypeSafe_StronglyType.Demo();

Console.WriteLine(" ------------------------- Collections ---------------------------------------- ");

Collections.Demo_Array();

Collections.Demo_ArrayList();

MyClass myClass = new MyClass();
myClass.Print("Hello!");
//myClass.TopSecret();

//Not accesible here
//IMySecret mySecret = new MyClass();

GenericDelegate.DemoGenericDelegate();


Collections.Demo_List();

Collections.Demo_Dictionary();

Collections.Demo_Hashtable();

Collections.Demo_HashSet();

Collections.Demo_SortedList();

Console.WriteLine(" ------------------------- Extension Method ---------------------------------------- ");


ToDo_ExtensionMethod.DemoExtensionMethod();

Console.WriteLine(" ------------------------- Structure ---------------------------------------- ");

DemoStruct.DemoStucture();

Console.WriteLine(" ------------------------- Stack n Queue ---------------------------------------- ");

Stack_N_Queue.Demo_Stack();

Stack_N_Queue.Demo_Queue();

Console.WriteLine(" ------------------------- String_vs_StringBuilder ---------------------------------------- ");

String_vs_StringBuilder.Demo_String_vs_StringBuilder();

Serialization_Deserialization.Demo_Serialization_Desearialization();

CommonLibrary.CSharp_Basic.Enum.Demo_Enum();

Console.WriteLine("Application Finished Executing!!");