﻿using System;
using CommonLibrary;
using CommonLibrary.CSharp_Basic;
using System.Reflection.Metadata;
using static CommonLibrary.CSharp_Basic.APublicClassToDemoOtherAccessModifier;
using ConsoleApp_Old;
using ConsoleApp_New;
using CommonLibrary.OOPs;
using CommonLibrary.OOPs.Inheritance;
using CommonLibrary.OOPs.Polymorphism;


namespace Misc
{

	public class Miscc
	{

		public void Method()
		{
			Console.WriteLine(" ------------------------- File System---------------------------------------- ");
			FileSystem.DemoFileSystem();
			Console.WriteLine("Application Finished Executing!!");
		}
	}
}