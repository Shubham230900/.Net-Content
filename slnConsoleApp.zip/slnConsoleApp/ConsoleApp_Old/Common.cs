﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Old_New
{

	internal class CommonClassDemo
	{

	}

	public interface IAnkit
	{
		void show();
	}

	public class ClassA
	{
		public ClassA()
		{

		}

		public string Name { get; set; }

		public string NewName;
	}

	public class CommonDemo
	{

		public string Name { get; set; }

		public static void Demo(ClassA obj)
		{
			//obj.Name = "XYZ";
			//obj.NewName = "xyzNew";
		}

		public void AddTwoNumbers()
		{
			Console.WriteLine("Hello! Please enter your first number.");
			int valOne = Convert.ToInt32(Console.ReadLine());

			Console.WriteLine("Hello! Please enter your second number.");
			int valTwo = Convert.ToInt32(Console.ReadLine());

			Console.WriteLine(valOne + valTwo);
		}

		public void ShowMessage(string str)
		{
			Console.WriteLine(str);
		}


		public void ForLoop()
		{
			for (int i = 1; i <= 100; i++)
			{
				Console.WriteLine(i);
			}
		}

		public void ReverseForLoop()
		{
			for (int i = 100; i > 0; --i)
			{
				Console.WriteLine(i);
			}
		}


		public void CommonMain()
		{
			//int i = 10;
			//int j = i;

			//Common obj = new Common();
			//obj.Demo(i);

			//Console.WriteLine(i);
			//Console.WriteLine(j);

			//string strOne = "ABC";
			//string strTwo = strOne;

			//Common obj = new Common();
			//obj.Demo(strTwo);

			//Console.WriteLine(strOne);
			//Console.WriteLine(strTwo);

			ClassA objA1 = new ClassA();
			objA1.Name = "Ankit";               //values are stored on heap
			objA1.NewName = "AnkitNew";

			ClassA objA2 = objA1; //obj and classes are reference type

			CommonDemo obj = new CommonDemo();
			CommonDemo.Demo(objA2);
			obj.Name = "khlcgjhkhljvh";

			Console.WriteLine(obj.Name);

			Console.WriteLine(objA1.Name);
			Console.WriteLine(objA2.Name);
		}
	}
}
