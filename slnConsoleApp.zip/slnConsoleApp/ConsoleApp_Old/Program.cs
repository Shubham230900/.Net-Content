﻿using ConsoleApp_Old;
using CommonLibrary;
using System;
using ConsoleApp_Old_New;

namespace ConsoleApp_Old
{

	#region FileSystem




	#endregion


	internal class Program
	{
		static void Main(string[] args)
		{
			CommonDemo.Demo(null);

			Console.WriteLine("Hello, World!");

			Console.ReadLine();
		}
	}
}
