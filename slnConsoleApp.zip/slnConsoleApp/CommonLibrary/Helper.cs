﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary
{
    public class HelperClass
    {

        public void ShowMsg(string str)
		{
            Console.WriteLine(str);
		}

    }


    public class Program
	{
        public static void Main(string[] args)
        {

        }
    }

}
