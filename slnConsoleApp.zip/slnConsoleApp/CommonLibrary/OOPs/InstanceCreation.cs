﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.OOPs
{

	//Method

	public class ParentClass
	{
		public ParentClass()
		{
			Console.WriteLine("ParentClass ctor");
		}

		public void ShowMsg()
		{
			Console.WriteLine("ShowMsg from ParentClass called");
		}
	}

	public class ChildClass : ParentClass
	{
		public ChildClass()
		{
			Console.WriteLine("ParentClass ctor");
		}

		public void ShowMsg()
		{
			base.ShowMsg();	//this is how you call method of Parent class in Child class
			Console.WriteLine("ShowMsg from ChildClass called");
		}
	}

}
