﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CommonLibrary.OOPs.Inheritance
{

	public class Parent
	{
		public int Id { get; set; }

		public Parent()
        {
			Console.WriteLine("Parent ctor is called.");
			this.Id = 1300;
		}

		public void ShowMsg()
		{
			this.Id = 1000;
			Console.WriteLine("Show msg is called.");
		}

		private void PrivateMethod()
		{
			Console.WriteLine("PrivateMethod is called");
		}
	}

	public class Child : Parent
	{
		int Id = 1098;

        public Child()
        {
			Console.WriteLine("Child ctor is called.");
		}

		public void Print()
		{
			Console.WriteLine("Print is called" + Id);
			ShowMsg();
			Console.WriteLine("Print is called" + Id);

			//private is non accessible 
			//base.PrivateMethod();
		}

	}



}
