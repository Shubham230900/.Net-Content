﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.OOPs.CTORChaining
{	
	public class GrandFather
	{
		public int HouseNumber { get; set; }
		public string HouseAddress { get; set; }

		public GrandFather()
		{
			Console.WriteLine("GrandFather ctor is called.");
		}
	}


	public class Parent : GrandFather
	{
		public Parent()
		{
			Console.WriteLine("Parent ctor is called.");
			this.HouseNumber = 234;
			this.HouseAddress = "Rabale";
		}

		public Parent(int a)
		{
			Console.WriteLine("Parent's parametrize ctor" + a);
		}

		public string BragAboutTheProperty()
		{
			return "See i am so richhhhhhh.... " + this.HouseNumber + " " + this.HouseAddress;
		}
	}

	public class Child : Parent
	{
		public Child() : this(10000)    //Calling the self parameterize ctor
		{
			Console.WriteLine("Child ctor is called.");
		}

		public Child(int a) : base(123)	//calling base class's parameterize ctor.
		{

		}

		public string BuildMoreProperty()
		{
			HouseNumber = 123;
			HouseAddress = "Parel";

			base.BragAboutTheProperty();

			return BragAboutTheProperty();
		}
	}


}
