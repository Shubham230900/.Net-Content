﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.OOPs
{
	public class MethodOverloading		// It is Compile time polymorphism
	{

		#region ConstructorOverloading

		public MethodOverloading() { } //	<-- Deafult Ctor

		public MethodOverloading(int a) { } //	<-- Parameterize Ctor with 1 param

		public MethodOverloading(int a, string str) { } //	<-- Parameterize Ctor with 2 params

		#endregion

		#region OperatorOverloading

		public void OperatorOverloading()
		{
			//In below example the + operator is being overloaded

			int a = 10;
			int b = 20;
			int c = a + b;			//here + operator is responsible for addition
			//Output = 30			

			string strOne = "10";
			string strTwo = "20";
			string strThree =  strOne + strTwo; //here + operator is responsible for concatenation
			//output = "1020"
		}

		#endregion

		#region MethodOverloading

		public void MyMethod()
		{

		}

		public void MyMethod(int a)
		{

		}

		//This will also not work
		//coz compiler is not able to distinguish between the method with the return type
		//public int MyMethod()
		//{
		//	return 10;
		//}

		public void MyMethod(string a, int b = 0)
		{
			Console.WriteLine(a);
			Console.WriteLine(b);
		}

		public void MyMethod(string a)
		{
			Console.WriteLine(a);
		}

		#endregion

	}
}
