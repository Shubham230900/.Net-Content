﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.OOPs.Polymorphism
{
	//Runtime Polymorphism -> Method Overriding -> virtual and override
	public class MyClassOne	//Parent class
	{
		public MyClassOne()
		{
			Console.WriteLine("MyClassOne ctor is called");
		}
		public void Show()
		{
			Console.WriteLine("Hello!");
		}

		public void Print()
		{
			Console.WriteLine("MyClassOne: Print");
		}

		public virtual void Show(string str)
		{			
			Console.WriteLine("MyClassOne: " + str);
		}
	}

	public class MyClassTwo : MyClassOne	//ChildClass
	{
		public MyClassTwo()
		{
			Console.WriteLine("MyClassTwo ctor is called");
		}

		public void Print()
		{
			Console.WriteLine("MyClassTwo: Print");
		}

		//Method with the same name and signature in the child clas
		public override void Show(string str)
		{
			Console.WriteLine("MyClassTwo: " + str);
		}
	}


}
