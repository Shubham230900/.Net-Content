﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//https://www.tutorialsteacher.com/csharp/association-and-composition


	public class Demonstarte
	{
		public void Demo()
		{
			#region Association

			StudentClass obj = new StudentClass();
			obj.Id = 1;
			obj.Address = "";
			obj.Name = "Test";

			StudentRepository obj2 = new StudentRepository();
			obj2.Create(obj);

			#endregion


			#region Composition

			Teacher objT = new Teacher();
			objT.Id = 2;
			objT.Name = "Test";

			Address objAddress = new Address();
			objAddress.Id = 3;
			objAddress.CityName = "Test";

			objT.Address = objAddress;

			#endregion


			#region Aggregation

			Subject objSubject = new Subject();
			objAddress.Id = 1;
			objAddress.CityName = "Math";

			TeacherClass objTeacherClass = new TeacherClass();
			objTeacherClass.Id = 2;
			objTeacherClass.Name = "Test";

			//objTeacherClass.Subject = objSubject;
			objTeacherClass.SubjectId = 1;

			#endregion

		}
	}

	#region AssociationExample


	public class StudentClass
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }

		//public StudentClass()
		//{
		//	this.Id = 0;
		//	this.Name = "0";
		//	this.Address = "0";
		//}

		//public StudentClass(StudentClass student)
		//{
		//	if (student != null)
		//	{
		//		this.Id = student.Id;
		//		this.Name = student.Name;
		//		this.Address = student.Address;
		//	}
		//	//else
		//	//{
		//	//	this.Id = 0;
		//	//	this.Name = "0";
		//	//	this.Address = "0";
		//	//}
		//}
	}

	//CRUD -> Create / Read / Update / Delete - Require Database communication services
	public class StudentRepository  //StudentRepository uses StudentClass to execute some functionality.
	{
		public StudentRepository() { }

		public int Create(StudentClass student)
		{
			//logic to add student in database
			return 0;
		}

		//public StudentClass Read(int studentId)
		//{
		//	//logic to retrieve student from database
		//	return new StudentClass() { };
		//}

		public bool Update(StudentClass student)
		{
			//logic to update student in database
			return true;
		}

		public bool Delete(int studentId)
		{
			//logic to delete student from database
			return true;
		}

	}

	#endregion

	#region CompositionExample

	public class Teacher
	{
		public int Id { get; set; }
		public string Name { get; set; }

		//Intance property of another class - which can not exist on its own and even if you create its own object it still needs some meaningful relationship with another class
		public Address Address { get; set; }
	}

	public class Address
	{
		public int Id { get; set; }
		public string HouseNumber { get; set; }
		public string CityName { get; set; }
	}



	#endregion

	#region AggregationExample

	public class TeacherClass
	{
		public int Id { get; set; }
		public string Name { get; set; }

		//Intance property of another class - which can exist on its own
		public Subject Subject { get; set; }

		public int SubjectId { get; set; }
	}

	public class Subject
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}



	#endregion

}
