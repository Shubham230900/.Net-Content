﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class TypeSafe_StronglyType
	{

		public static void Change(object obj)
		{
			obj = 12;
		}

		public static void ChangeOut(out object obj)
		{
			obj = 12;
		}

		public static void Demo()
		{
			MyCustomType obj = new MyCustomType();
			Change(obj);

			//ChangeOut(out obj);	//CompileTime Error

			object oo = obj;
			ChangeOut(out oo); //No error as now both are of same type.



			//Error - array can't have 
			//intArr[2] = "abc"; //<-------strongly typed //<-- drawback

			var data = "stromh";
			//data = 12; //<---- this is giving error as var is a strongly typed -> gives compile time error


			bool IsString = string.IsNullOrEmpty(data); //<- if you pass int value in data then it will show error as we can't perform IsNullOrEmpty check.

		}

		public class MyCustomType
		{

		}


	}
}
