﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class ExceptionHandling
	{

		////cannot have both catch and catch(Exception ex)

		public static void NormalMethod()
		{
			try //this is the outer Try-Catch block 
			{
				//Solution_Without_Throw();
				Solution_With_Throw_Only();
				//Solution_With_Throw_Exception();
			}
			catch
			{

			}
		}

		public static void Problem()
		{
			int a = 0;
			//a = "dgfhjkl";			//Compile Time Error

			int b = 100;

			int c = b / a;              //Run Time Error/Exception
		}

		//Handle the Run Time Error/Exception
		public static void Solution_Basic()
		{
			try
			{

				int a = 0;

				//a = "dgfhjkl";			//Compile Time Error --> No solution of compile time error apart from solving them before build/execution.

				int b = 100;

				int c = b / a;              //Run Time Error/Exception

			}
			catch
			{
				Console.WriteLine("Oops! An error occurred.");
			}
		}

		public static void Solution_Advance()
		{
			try
			{

				int a = 0;

				//a = "dgfhjkl";			//Compile Time Error --> No solution of compile time error apart from solving them before build/execution.

				int b = 100;

				int c = b / a;              //Run Time Error/Exception

			}
			catch (Exception ex)
			{
				Console.WriteLine("Oops! An error occurred.");
				Console.WriteLine("Error Message: ");
				Console.WriteLine(ex.Message);
			}
		}



		#region MultipleCatchBlock


		public static void MultipleException(string str)
		{		
			try
			{
				//System will not raise below error as system is fine with "str" parameter having a null value
				//but as a developer we don't want to accept Null value in the "str" parameter so we can manually raise/throw an exception.
				if (string.IsNullOrWhiteSpace(str))
					throw new ArgumentNullException();

				int[] arr = new int[2];

				arr[0] = 1;
				arr[1] = 0;

				Console.WriteLine(arr[0]);
				Console.WriteLine(arr[1]);

				Console.WriteLine(arr[2]);          //Run Time Error

				int c = arr[0] / arr[1];            //Division Error
			}
			catch (ArgumentNullException exOne)
			{
				Console.WriteLine(exOne.Message);
			}
			catch (IndexOutOfRangeException exTwo)
			{
				Console.WriteLine("Index out of range.");
			}
			catch (DivideByZeroException ex)
			{
				Console.WriteLine("Can't divide by Zero (0).");
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
			finally
			{
				//Finally block is always executed even if there are error/exceptions in the respective method.
				//finally block can exists without a catch block
				Console.WriteLine("MultipleException Completed!!");
			}
						
		}


		#endregion




		#region ThrowKeyword

		public static void Solution_Without_Throw()
		{
			try
			{

				int a = 0;

				//a = "dgfhjkl";			//Compile Time Error --> No solution of compile time error apart from solving them before build/execution.

				int b = 100;

				int c = b / a;              //Run Time Error/Exception

			}
			catch (Exception ex)
			{
				Console.WriteLine("Oops! An error occurred.");
				Console.WriteLine("Error Message: ");
				Console.WriteLine(ex.Message);
			}
		}

		public static void Solution_With_Throw_Exception()
		{
			try
			{

				int a = 0;

				//a = "dgfhjkl";			//Compile Time Error --> No solution of compile time error apart from solving them before build/execution.

				int b = 100;

				int c = b / a;              //Run Time Error/Exception

			}
			catch (Exception ex)
			{
				//Console.WriteLine("Oops! An error occurred.");
				//Console.WriteLine("Error Message: ");
				//Console.WriteLine(ex.Message);

				throw ex;
			}
		}

		//Always use Throw alone when you want to have a detailed stack tract for an error.
		public static void Solution_With_Throw_Only()
		{
			try
			{

				int a = 0;

				//a = "dgfhjkl";			//Compile Time Error --> No solution of compile time error apart from solving them before build/execution.

				int b = 100;

				int c = b / a;              //Run Time Error/Exception

			}
			catch
			{
				throw;
			}
		}

		#endregion

	}
}
