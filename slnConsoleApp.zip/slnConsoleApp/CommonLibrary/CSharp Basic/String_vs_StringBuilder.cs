﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class String_vs_StringBuilder
	{

		public unsafe static void Demo_String_vs_StringBuilder()
		{

			//string strHash = "A";
			//Console.WriteLine(strHash.GetHashCode());
			//strHash = strHash + "";
			//Console.WriteLine(strHash.GetHashCode());

			//String
			string strNull;

			string str = "";

			string strValue = string.Empty;//""

			String strNew = "";

			if (str == strValue)
			{
				Console.WriteLine("Equal");
			}

			if (str == strNew)
			{
				Console.WriteLine("Equal");
			}

			//Whenever string is assigned a new value a new memory location is created.

			string strInital = "Hiiiii";    //initial memory location --> #67765

			strInital = "Hello! World...........";  //new memory location //#98765

			strInital = strInital + "My name is John";          //New memory


			//*** Important
			//string* ptr1 = &strInital
			//This is poiting towards the stack memory - which is holding the memory address
			//of the heap memory where the value is actually stored.
			//Stack memory which stores the reference of the string variable will remains same
			//even if we alter the string, as the new value will be created on the new heap memory
			//and new heap memory address will be updated on the existing stack memory location.


			string* ptr1 = &strInital;		
			Console.WriteLine((int)ptr1);
			Console.WriteLine(*ptr1);

			strInital = strInital + "I read in class 5";        //New memory

			string* ptr2 = &strInital;
			Console.WriteLine((int)ptr2);
			Console.WriteLine(*ptr2);

			strInital = strInital + "I am from Mumbai";         //New memory

			string* ptr3 = &strInital;
			Console.WriteLine((int)ptr3);
			Console.WriteLine(*ptr3);

			strInital = strInital + "Thanks";                   //New memory

			string* ptr4 = &strInital;
			Console.WriteLine((int)ptr4);
			Console.WriteLine(*ptr4);

			//Strings are immutable -> does not change the value
			//but rather creates a new memory location and then stores the value on the new location.
			//old memory location where old string is residing is cleared by CLR's garbage collector

			//We should not use String/string if we want to perform frequent update to the string.
			//instead we should use StringBuilder class


			//StringBuilder object is Mutable -> which means the value will be updated on the same memory location
			//and the memory location will never change even on update

			StringBuilder sb = new StringBuilder(); //Initial Memory location
			sb.AppendLine("Hi");                    //Memory location -> same as initial memory location
			sb.AppendLine("Kem Cho");
			sb.AppendLine("Mazaaa Maaaa");          //Memory location -> same as initial memory location
			sb.AppendLine("Heji reeeeeeee");
			sb.AppendLine("Haalooooooooooooo");     //Memory location -> same as initial memory location

			sb.Append("Haalooooooooooooo");     //Memory location -> same as initial memory location
			sb.Append(" - Re - Haalooooooooooooo");
			Console.WriteLine(sb);


			string strStringBuilderString = sb.ToString();


			#region Misc

			char[] charArr = new char[10];  //this is equvilant to a pointer in C++
			string strArr = new String(charArr);

			string abc = "abcdefghijklmnopqrstuvwxyz";

			char[] abcArr = abc.ToCharArray();

			string strVal = "1234567";
			Update(ref strVal);
			Console.WriteLine(strVal);

			#endregion

		}
		public static void Update(ref string str)
		{
			str = "156789";
		}

	}
}
