﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Operator
	{
		public Operator() { }


		public void DemoArray()
		{
			int[] arr = { 1, 2, 4, 5, 6, 7, 7, 8, 8, 98 };

			Array.Sort(arr);

			PrintArray(arr);

			Console.WriteLine(" ------------------------------ ");

			Array.Reverse(arr);

			PrintArray(arr);


			string str = "abcdefghijklmnopqrstuvwxyz";

			char[] arr2 = str.ToCharArray();


		}

		public void PrintArray(int[] arr)
		{
			foreach (int i in arr)
			{
				Console.WriteLine(i);
			}
		}

		public void DemoOperator()
		{
			//Int addition
			int a = 10;
			int b = 20;
			int c = a + b;
			Console.WriteLine(c);

			//String concatenation
			string aStr = "Moye";
			string bStr = "QWERTY";
			string cStr = aStr + bStr;
			Console.WriteLine(cStr);

			int intA = 10;
			int intB = 10;
			int intC = 20;
			int intD = 30;
			int intE = 20;
			int intF = 20;
			int intG = 20;
			//Note:
			//XOR operator will only provide you the unique number for a given set when
			//you have the repetition of the number in even times.
			//for ex: in above example 20 and 10 is repeated in even times.
			int intH = intA ^ intB ^ intC ^ intD ^ intE ^ intF ^ intG;
			Console.WriteLine(intH);


			for (int i = 100; i > 0; i--)
			{
				bool condtion1 = i % 4 == 0;
				bool condtion2 = i % 5 == 0;

				if (condtion1 && condtion2)
					Console.WriteLine(i);

				else if (condtion1)
					Console.WriteLine(i);

				else if (condtion2)
					Console.WriteLine(i);

				else
					Console.WriteLine(i);
			}

			//switch case -> Homework





		}


		public void DemoOptionalParameter(int a, int b = 10)
		{
			Console.WriteLine(a + b);
		}

		public void DemoOptionalParameter(string strFirstName, string strLastName, string strTitle = "Mr.")
		{
			Console.WriteLine(strTitle + " " + strFirstName + " " + strLastName);
		}

		public void DemoOptional(int a, int c, int b = 10, int x = 9, string str = "")
		{
			Console.WriteLine(a + b);
		}
	}
}
