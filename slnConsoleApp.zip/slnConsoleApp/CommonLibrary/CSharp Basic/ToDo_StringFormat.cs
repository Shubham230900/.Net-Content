﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	internal class ToDo_StringFormat
	{

		//String formats 
		// 12345678 => 12,345,678
		// 07-Mar-2009 => 03/07/2009
	}
}
