﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class DataType_Conversion
	{
		public void Demo()
		{
			DataTypeDemo(10, "hello", 'b', (decimal)10.56, 1.345678f, 234567890, 123, (long)123456.654321, true, DateTime.Now);

			decimal d1 = Convert.ToDecimal(234.2);
			decimal d2 = 234.2m;
			decimal d3 = (decimal)234.2;

			int xray = 2345;
			string strXray = Convert.ToString(xray); // "2345"

			//ShowMsg("qwerty new");
		}

		public void DataTypeDemo(int a, string str, char chr, decimal deci, float flo, double dou, short sho, long lon, bool isFalse, DateTime dateTime)
		{
			var data = 567890;
			//data = "adsa"; //this is not allowed
			data = 50;

			str = "rtd,yfugih,ojpkihu,gfzdzxc,hgjkhl";


			char[] arrChar = str.ToCharArray();			

			string[] arr = str.Split(',');


		}


		public void DemoMethod()
		{
			Console.WriteLine("Hi");

			void SendMail(string strMsg, string email = "")
			{
				Console.WriteLine("Hello! " + strMsg);
			}

			SendMail("Hi");

			SendMail("Hellooooooo");
		}


		//private void ShowMsg(string strMsg) 
		//{
		//	Console.WriteLine("Hello! " + strMsg);
		//}


	}
}
