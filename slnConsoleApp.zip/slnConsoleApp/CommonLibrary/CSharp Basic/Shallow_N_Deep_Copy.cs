﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//Point of Reference
	//https://www.geeksforgeeks.org/shallow-copy-and-deep-copy-in-c-sharp/

	internal class Shallow_N_Deep_Copy
	{
	}

	public class Animal
	{
		public Animal() { }

		//Copy Constructor
		//Creates a new instance of the class but with the values of a gives object of its own type
		public Animal(Animal obj)
		{
			this.Id = obj.Id;
			this.Address = obj.Address;
			this.Name = obj.Name;
		}

		//Provides the same instance -> hence reference is intact.
		public Animal ShallowCopy()
		{
			return (Animal)this.MemberwiseClone();
		}

		//Provides a new instance with the value of existing instance of the given object.
		//As it is a new instance so the reference will be different
		public Animal DeepCopy()
		{
			Animal objNew = new Animal() { Id = this.Id, Address = this.Address, Name = this.Name };			
			return objNew;
		}

		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
	}
}

