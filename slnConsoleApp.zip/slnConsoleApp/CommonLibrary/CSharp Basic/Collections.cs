﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CommonLibrary.CSharp_Basic
{
	public class Collections
	{

		public void MethodA(string b, int a, int c)
		{

		}

		public void MethodA(int a, string b, int c)
		{

		}

		public static void Demo_Array()
		{



			//collection -> group of things / items
			//A basket of Apple --> collection of Apple (type) where Basket (container) is used to hold the apple

			//-----------------Array

			Array array = new int[12];

			int[] numberArray = { 1, 2, 3, 4, 5, 6, 7, 8, };

			string[] stringArrayOne = new string[] { "A", "B", "C", "D", "E" };
			string[] stringArrayTwo = { "A", "B", "C", "D", "E" };

			string[] stringArrayNew = new string[5];
			stringArrayNew[0] = "A1";
			stringArrayNew[1] = "A2";
			stringArrayNew[2] = "A3";
			stringArrayNew[3] = "A4";
			stringArrayNew[4] = "A5";

			foreach (var i in numberArray)
			{
				Console.Write(i);
			}

			int[] intArr = new int[2]; //size is defined
			intArr[0] = 1;
			intArr[1] = 2;

			//intArr[2] = "dfghj";	//can't store different data type here

			intArr[1] = Convert.ToInt32("3");
			intArr[0] = int.Parse("4");

		}

		public static void Demo_ArrayList()
		{

			//2,3,5,6,8,9,9
			//"asd", "asea", "asdfaef", "afafsadf", "asAF", "dsads"

			int[] numberArray = { 1, 2, 3, 4, 5, 6, };

			int val1 = numberArray[3];

			//Non Generic Collection -> Can have different types of value
			ArrayList objArr = new ArrayList();

			objArr.Add("1");
			objArr.Add("2");
			objArr.Add(3);
			objArr.Add(4);
			objArr.Add("Ankit");
			objArr.Add(numberArray);
			objArr.Add(null);

			ArrayList arrLst = new ArrayList()
			{
				2,      //object{int}
				"Ankit",
				23456,
				new int[] { 1,3,5}
			};

			//ArrayList uses concept of Boxing while storing the value
			//We have to unbox the values of the arrayList while reading
			foreach (var i in arrLst)
			{
				if (i is int[]) //old alternate --> //if ( i.GetType() == typeof(int[]) )
				{
					foreach (var v in (int[])i)
					{
						Console.WriteLine(v);
					}
				}
				else
					Console.WriteLine(i);
			}

			for (int i = 0; i < arrLst.Count; i++)
			{
				Console.WriteLine(arrLst[i]);
			}

			int value = (int)arrLst[0];

			var val = arrLst[1];

			//Insert Value at a particular location
			arrLst.Insert(1, "Ram");
			arrLst.Insert(2, 45678);

			//Insert multiple value -> InsertRange
			arrLst.InsertRange(3, objArr);

			arrLst.Insert(7, objArr);

			//Remove

			//Remove-RemoveAt-RemoveRange

			arrLst.Remove("Ankit");

			arrLst.RemoveAt(7);

			arrLst.RemoveRange(4, 5);


			//To check if the list contains a particular element
			bool listHasElement = arrLst.Contains("Ankit");

		}


		public static void Demo_List()
		{
			List<string> strings = new List<string>() { "A", "ABC", "GGH", "SDFYGU", "09876" };

			List<string> strings2;
			strings2 = new List<string>() { "A", "678" };

			#region Create

			List<int> lstInt = new List<int>();
			lstInt.Add(1);
			lstInt.Add(2);
			lstInt.Add(3);
			lstInt.Add(4);
			//lstInt.Add("5");	//Error can't accept other types
			//lstInt.Add(true);	//Error can't accept other types

			lstInt.AddRange(new List<int>() { 56, 678, 678, 6789 });

			int[] arr = new int[] { 1, 2, 56789, 45 };

			lstInt.AddRange(arr);

			lstInt.Insert(4, 789);
			lstInt.InsertRange(2, new List<int>() { 56, 1234 });

			//List<object> obj = new List<object>();

			//Fetch data using indexers
			var data1 = lstInt[0];
			var data2 = lstInt[1];
			var data3 = lstInt[2];

			#endregion


			#region ReadValue

			for (int i = 0; i < lstInt.Count; i++)
			{
				Console.WriteLine(lstInt[i]);
			}
			//Or
			foreach (var value in lstInt)
			{
				Console.WriteLine(value);
			}
			//Or
			lstInt.ForEach(value => { Console.WriteLine(value); });

			#endregion


			#region Update

			var existingValue = lstInt[0];
			lstInt[0] = 78;

			//Agenda to update the List

			for (int i = 0; i < lstInt.Count; i++)
			{
				lstInt[i] = lstInt[i] * 10;
			}

			//This will not update/alter the existing lstInt object which iS of type List<int>
			lstInt.ForEach(itm => { itm = itm * 10; });

			lstInt.Add(123456);
			lstInt.Add(1234560);
			lstInt.Add(123);
			//agenda to delete numbers which are divisible by 5 -> use reverse array traversing.
			for (int i = lstInt.Count - 1; i >= 0; i--)
			{
				if (lstInt[i] % 5 == 0)
				{
					lstInt.Remove(lstInt[i]);
				}
			}



			//agenda to delete numbers which are divisible by 3
			try
			{
				//Wrong Way -> coz collection should not be modified while iteration
				foreach (var r in lstInt)
				{
					if (r % 3 == 0)
					{
						lstInt.Remove(r);
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			//Correct Way of deleting all the value which are divisible by 3
			lstInt.RemoveAll(x => x % 3 == 0);

			//get all items which are divisible by 3
			var iEnumDivByFive = lstInt.Where(x => x % 5 == 0);

			//Indexing in IEnumberable is not present
			//var dataz = iEnumDivByThree[0];

			//how to convert IEnumerable to List
			var lstDivByFive = iEnumDivByFive.ToList();

			if (lstInt.Contains(12340))
			{
				Console.Write("12340 Exists");
			}




			List<int> list = new List<int>();
			foreach (var r in lstInt)
			{
				list.Add(r * 10);
			}


			//To clear the entire list
			lstInt.Clear();

			#endregion
			string[] arrString = new string[] { "safg", "fff", "fff", "fff" };

			List<string> lstSting = new List<string>() { "ABC", "XYZ", "UVW", "Ankit", "Shyam", "Sunder", "Atif", "Alia", "Rashmi", "Ankit" };

			var indexOf = lstSting.IndexOf("Ankit");

			var lastIndexOf = lstSting.LastIndexOf("Ankit");

			bool isPresent = lstSting.Contains("Ankit");

			lstSting.Add("Ankita");

			lstSting.AddRange(arrString);

			lstSting.RemoveAll(x => x.StartsWith("A"));


			//In Database data will be represented in the form of Tables (collection of rows and columns)
			//Id	Name	Address
			//1		Atif	Mumbai
			//2		John	Mumbai

			//Represent above data in JSON format
			#region JsonFormat
			//[
			//  {
			//	Id: 1,
			//	Name: "Atif",
			//	Address: "Mumbai"
			//  },
			//  {
			//	Id: 2,
			//	Name: "John",
			//	Address: "Mumbai"
			//  }
			//]
			#endregion

			//Represent above data in XML format
			#region XML Format
			//<?xml version = "1.0" encoding = "UTF-8" ?>
			//<root>
			//	<0>
			//		<Id>1</Id>
			//		<Name>Atif</Name>
			//		<Address>Mumbai</Address>
			//	</0>
			//	<1>
			//		<Id>2</Id>
			//		<Name>John</Name>
			//		<Address>Mumbai</Address>
			//	</1>
			//</root>
			#endregion


			//Represent above data in Class n Object (see below 2 objects: teacherOne n teacherTwo)

			//Object List
			MumbaiTeacher teacherOne = new MumbaiTeacher();
			teacherOne.Id = 1;
			teacherOne.Name = "Atif";
			teacherOne.Address = "Mumbai";

			MumbaiTeacher teacherTwo = new MumbaiTeacher()
			{
				Id = 2,
				Name = "John",
				Address = "Mumbai"
			};

			List<MumbaiTeacher> lstMumbaiTeacher = new List<MumbaiTeacher>();

			lstMumbaiTeacher.Add(teacherOne);
			lstMumbaiTeacher.Add(teacherTwo);

			//Print values of all the objects one by one
			foreach (var row in lstMumbaiTeacher)
			{
				Console.WriteLine(row.Id);
				Console.WriteLine(row.Name);
				Console.WriteLine(row.Address);
			}

			var firstMumbaiTeacher = lstMumbaiTeacher[0]; //using indexers
														  //var firstMumbaiTeacher = lstMumbaiTeacher.First(); //using extension methods

			var lastMumbaiTeacher = lstMumbaiTeacher.Last(); //using extension methods

			MumbaiTeacher teacherThree = new MumbaiTeacher()
			{
				Id = 3,
				Name = "Ankit",
				Address = "Jaipur/Mumbai"
			};

			//Added a new teacher
			lstMumbaiTeacher.Add(teacherThree);

			MumbaiTeacher[] lstNewArr = new MumbaiTeacher[5];
			lstMumbaiTeacher.CopyTo(lstNewArr);

			//Runtime exception as the below list will create an empty array and later CopyTo will not be able to push data into an empty array
			//that's y we will see a runtime exception
			//var lstNew = new List<MumbaiTeacher>();
			//lstMumbaiTeacher.CopyTo(lstNew.ToArray());			

			var objClone = "qwertyu";
			object str = objClone.Clone();

			//shallow copy
			//deep copy
			//obj1 --> obj2 

		}


		public static void Demo_Dictionary()
		{
			KeyValuePair<int, string> keyValuePairOne = new KeyValuePair<int, string>(1, "Lion");
			Console.WriteLine("keyValuePairOne.Key = " + keyValuePairOne.Key);
			Console.WriteLine("keyValuePairOne.Value = " + keyValuePairOne.Value);

			KeyValuePair<int, string> keyValuePairTwo = new KeyValuePair<int, string>(2, "Elephant");
			Console.WriteLine("keyValuePairTwo.Key = " + keyValuePairTwo.Key);
			Console.WriteLine("keyValuePairTwo.Value = " + keyValuePairTwo.Value);

			//*** We can't add KeyValuePair directly to a Dictionary type object
			//Dictionary<int, string> dicKeyValuePairs = new Dictionary<int, string>();
			//dicKeyValuePairs.Add(keyValuePairOne);

			//*** We should use IDictionary type of object to be able to add keyvaluepairs direcytly.
			IDictionary<int, string> docKeyValuePairs = new Dictionary<int, string>();
			docKeyValuePairs.Add(keyValuePairOne);
			docKeyValuePairs.Add(keyValuePairTwo);
			docKeyValuePairs.Add(new KeyValuePair<int, string>(3, "Cat"));



			// ---------------------------------------------------------------------------- //


			Dictionary<int, string> dic = new Dictionary<int, string>();

			dic.Add(1, "Atif");
			dic.Add(2, "John");

			dic.Add(3, "Atif"); //this is valid as key is unique but value can be duplicate or already existing in the dictionary

			dic.Add(20, "John1");
			dic.Add(2000, "John");
			dic.Add(56, "John34567");



			//Error - Compile Time Error
			//dic.Add(3, 100000); //not possible as value is declared as string in the dictionary signature

			//Error - Runtime Error
			//dic.Add(2, "Ankit"); //Key should be unique -> this will throw runtime exception

			foreach (KeyValuePair<int, string> item in dic)
			{
				Console.WriteLine("item.Key = " + item.Key);
				Console.WriteLine("item.Value = " + item.Value);
			}

			foreach (var item in dic)
			{
				Console.WriteLine("item.Key = " + item.Key);
				Console.WriteLine("item.Value = " + item.Value);
			}

			var itemValue = dic[56];//access value using a key

			//Check if key is present in the dictionary
			if (dic.TryGetValue(2000, out string val))
			{
				Console.WriteLine(val);
			}
			else
			{
				Console.WriteLine("Key not found!");
			}



			MumbaiTeacher teacherOne = new MumbaiTeacher();
			teacherOne.Id = 1;
			teacherOne.Name = "Atif";
			teacherOne.Address = "Mumbai";

			MumbaiTeacher teacherTwo = new MumbaiTeacher()
			{
				Id = 2,
				Name = "John",
				Address = "Mumbai"
			};


			Dictionary<string, MumbaiTeacher> dicTeacher = new Dictionary<string, MumbaiTeacher>();
			dicTeacher.Add("Atif", teacherOne);
			dicTeacher.Add("John", teacherTwo);


			MumbaiTeacher teacherThree = new MumbaiTeacher()
			{
				Id = 3,
				Name = "Johnny",
				Address = "Mumbai"
			};

			KeyValuePair<string, MumbaiTeacher> kvp = new KeyValuePair<string, MumbaiTeacher>("3", teacherThree);

			//add keyvaluepair using IDictionary in a new Dictionary
			IDictionary<string, MumbaiTeacher> dicKVP = new Dictionary<string, MumbaiTeacher>();
			dicKVP.Add(kvp);

			//Add keyvaluepair using IDictionary but in an already existing Dictionary (dicTeacher)
			IDictionary<string, MumbaiTeacher> dicKVPNew = dicTeacher;
			dicKVPNew.Add(kvp);

			//var dicClone = dicTeacher.

		}


		/// <summary>
		/// Non-Generic Collection		
		/// Key should be unique else it will throw run exception.
		/// </summary>
		public static void Demo_Hashtable()
		{
			Hashtable htbl = new Hashtable();
			htbl.Add("1", "234567890");
			htbl.Add(23456, "Ram");
			htbl.Add(2456, "Ra3233m2");
			htbl.Add(2356, "Ra33m1");
			htbl.Add(2346, "R15678am3");
			htbl.Add(3456, "Ram57");
			htbl.Add(2345, "Ram34567");

			//htbl.Add(23456, 5678);	//Error while adding the same key

			if (htbl.ContainsKey(23456))
			{
				Console.WriteLine(htbl[23456]);

				//Remove
				htbl.Remove(23456);
			}

			//Update
			htbl["1"] = "Ankit-Sharma";

			//Clear
			//htbl.Clear();

			Hashtable htbl2 = new Hashtable();
			htbl2 = htbl;

			htbl2["1"] = 12345;

			Hashtable htbl3 = new Hashtable();
			htbl3 = (Hashtable)htbl.Clone();

			htbl3["1"] = true;

			foreach (var key in htbl3.Keys)
			{
				Console.WriteLine(htbl3[key]);
			}

			foreach (DictionaryEntry en in htbl3)
			{
				Console.WriteLine("Key: {0} - Value: {1}", en.Key, en.Value);
			}

			//We can't cast DictionaryEntry to KeyValuePair<int, string>
			//foreach (KeyValuePair<int, string> en in htbl3)
			//{
			//	Console.WriteLine("Key: {0} - Value: {1}", en.Key, en.Value);
			//}

			//Unable to cast object of type DictionaryEntry to KeyValuePair<object, object>
			//foreach (KeyValuePair<object, object> en in htbl3)
			//{
			//	Console.WriteLine("Key: {0} - Value: {1}", en.Key, en.Value);
			//}
		}


		public static void Demo_HashSet()
		{
			HashSet<int> hs = new HashSet<int> { 1, 2, 3 };

			hs.Add(1);

			int[] arr = new int[] { 1, 2, 3, 5, 6, 8, 9, 53, 2, 4, 5, 7, 9, 4, 3, 2, 3, 5, 67, 4, 3, 3, 45, 688, 6, 54, 3, 3, 5, 6, 54, 4, 56, 78, 7, 654, 3, 45, 67 };

			HashSet<int> hsUnique = new HashSet<int>();
			HashSet<int> hsDuplicate = new HashSet<int>();
			foreach (int i in arr)
			{
				if (!hsUnique.Add(i))
				{
					hsDuplicate.Add(i);
				}
			}

			foreach (var item in hsUnique)
			{
				Console.WriteLine(item);
			}
			Console.WriteLine("------------ Duplicate -----------");
			foreach (var item in hsDuplicate)
			{
				Console.WriteLine(item);
			}

		}


		public static void Demo_SortedList()
		{
			//SortedList<int, string> lstSorted = new SortedList<int, string>();

			//lstSorted.Add(300, "456789");
			//lstSorted.Add(1, "456789");
			////lstSorted.Add("", ""); //compile time error
			//lstSorted.Add(0, "456789");

			//lstSorted.Add(250, "456789");

			SortedList<string, string> lstSorted = new SortedList<string, string>();

			//lstSorted.Add("300", "456789");
			//lstSorted.Add("3", "456789");
			//lstSorted.Add("1", "456789");
			//lstSorted.Add("20", ""); //compile time error
			//lstSorted.Add("0", "456789");
			//lstSorted.Add("250", "456789");


			//Standardization of numeric strings
			lstSorted.Add("300", "456789");
			lstSorted.Add("003", "456789");
			lstSorted.Add("001", "456789");
			lstSorted.Add("020", ""); //compile time error
			lstSorted.Add("000", "456789");
			lstSorted.Add("250", "456789");

			foreach (var itm in lstSorted)
			{
				Console.WriteLine("{0}-{1}", itm.Key, itm.Value);
			}

			//Before Sorting
			//"01.01.1" - Lion
			//"01.01.06" - Shyam
			//"01.01.10" - Sunder
			//"01.01.100" - Ankit

			//After Sorting


		}



	}

	//ADO.NET -> Entity Framework (Full ORM) -> Dapper (Light ORM)

	//WebAPI-1 (15) + WebAPI-2 (17) + WebAPI-3 (10) <= 20 (total number of hotel in that area)
	//15+17+10 = 42 records from all webAPI -> hotelID unique
	//List<hotel> hotels = new ....
	//hashset<int> hs= new....
	//hotels..OrderBy(x => x.HotelID).ThenBy(x => x.Price)
	//foreach(var hotel in hotels){  if(hs.Add(hotelID)){  //unique  }  else { //duplicate  } }
	//

	public class MumbaiTeacher
	{
		public MumbaiTeacher() { }

		//Provides the same instance -> hence reference is intact.
		public MumbaiTeacher ShallowCopy()
		{
			return (MumbaiTeacher)this.MemberwiseClone();
		}

		//Provides a new instance with the value of existing instance of the given object.
		//As it is a new instance so the reference will be different
		public MumbaiTeacher DeepCopy()
		{
			MumbaiTeacher objNew = new MumbaiTeacher() { Id = this.Id, Address = this.Address, Name = this.Name };
			return objNew;
		}

		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
	}

}



