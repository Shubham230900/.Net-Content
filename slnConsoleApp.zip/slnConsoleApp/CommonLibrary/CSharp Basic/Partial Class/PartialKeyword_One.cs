﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic.Partial_Class
{

	//partial keyword helps us to break a class into multiple files and classes but the class should be the member of same name space
	public partial class PartialKeyword
	{

		public void Show()
		{

		}

		//Long Class fILE
		//Long Class fILE
		//Long Class fILE
		//Long Class fILE
		//Long Class fILE
		//Long Class fILE
		//Long Class fILE
		//Long Class fILE

	}
}
