﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CommonLibrary.CSharp_Basic
{
	//Convert an object to other formats (JSON / XML etc)
	//Binary
	//XML
	//JSON

	[Serializable]
	public class Employee
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
	}



	public class Serialization_Deserialization
	{

		public static void Demo_Serialization_Desearialization()
		{

			#region DummyData

			#region Data_In_Database
			//In Database data will be represented in the form of Tables (collection of rows and columns)
			//Id	Name	Address
			//1		Atif	Mumbai
			//2		John	Mumbai
			#endregion

			#region Data_In_Json_Format
			//Represent above data in JSON format
			//[
			//  {
			//	Id: 1,
			//	Name: "Atif",
			//	Address: "Mumbai"
			//  },
			//  {
			//	Id: 2,
			//	Name: "John",
			//	Address: "Mumbai"
			//  }
			//]
			#endregion

			#region Data_In_XML_Format
			//Represent above data in XML format
			//<?xml version = "1.0" encoding = "UTF-8" ?>
			//<root>
			//	<0>
			//		<Id>1</Id>
			//		<Name>Atif</Name>
			//		<Address>Mumbai</Address>
			//	</0>
			//	<1>
			//		<Id>2</Id>
			//		<Name>John</Name>
			//		<Address>Mumbai</Address>
			//	</1>
			//</root>
			#endregion

			#endregion


			//Represent above data in Class n Object (see below 2 objects: teacherOne n teacherTwo)
			//Object List
			Employee empOne = new Employee();
			empOne.Id = 1;
			empOne.Name = "Atif";
			empOne.Address = "Mumbai";

			Employee empTwo = new Employee() { Id = 2, Name = "John", Address = "Mumbai" };

			List<Employee> lst = new List<Employee>() { empOne, empTwo };


			//Binary Formatter -> We should not use BinaryFormatter according to Microsoft
			//https://learn.microsoft.com/en-us/dotnet/standard/serialization/binaryformatter-security-guide

			#region Binary_Serialization-

			//BinaryFormatter bformatter = new BinaryFormatter();

			//#region Serialize

			//if (File.Exists("empOne.binary"))
			//	File.Delete("empOne.binary");

			//FileStream fileStream = new FileStream("empOne.binary", FileMode.Create, FileAccess.ReadWrite);
			//bformatter.Serialize(fileStream, empOne);
			//#endregion

			//#region Deserialize
			////Deserialize --- Read existing binary file and convert it to the object
			//FileStream fileStreamNew = new FileStream("empOne.binary", FileMode.Open, FileAccess.ReadWrite);
			//var objEmp = (Employee)bformatter.Deserialize(fileStreamNew);

			//Console.WriteLine("{0} {1} {2}", objEmp.Id, objEmp.Name, objEmp.Address);
			//#endregion

			#endregion


			#region XmlSerialization

			XmlSerializer serializer = new XmlSerializer(typeof(Employee));

			#region Serialize

			if (File.Exists("empOne.xml"))
				File.Delete("empOne.xml");

			FileStream fileStream = new FileStream("empOne.xml", FileMode.Create, FileAccess.ReadWrite);
			serializer.Serialize(fileStream, empOne);
			#endregion

			fileStream.Close();

			#region Deserialize
			//Deserialize --- Read existing binary file and convert it to the object
			FileStream fileStreamNew = new FileStream("empOne.xml", FileMode.Open, FileAccess.ReadWrite);
			var objEmp = (Employee)serializer.Deserialize(fileStreamNew);

			fileStreamNew.Close();

			Console.WriteLine("{0} {1} {2}", objEmp.Id, objEmp.Name, objEmp.Address);
			#endregion


			#endregion


			#region JsonSerialization

			Stream jsonFS_In = new FileStream("empOne.json", FileMode.Create, FileAccess.ReadWrite);
			JsonSerializer.Serialize(jsonFS_In, empOne, new JsonSerializerOptions() { });
			jsonFS_In.Close();

			string jsonFS_Out = File.ReadAllText("empOne.json");
			var objEmpNew = JsonSerializer.Deserialize<Employee>(jsonFS_Out);

			#endregion


		}



	}
}
