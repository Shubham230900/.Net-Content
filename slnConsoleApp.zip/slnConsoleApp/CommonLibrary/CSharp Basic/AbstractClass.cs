﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	//Abstract class can not be instantiated ... mean object can't be created
	//But abstract class can still have a constructor ... which is called when derived/child class's instance is created.
	//Abstract class can have both abstract and non abstract methods
	//Abstract class has to be inherited in the other class ----> 
	//The abstract Methods of abstract class has to be implemented in the child class.
	//We can't mark abstract class as Static or Sealed
	public abstract class Abstract_ParentClass     //Super class
	{		

		public Abstract_ParentClass()
		{
			Console.WriteLine("AbstractClass ctor");
		}

		public abstract string Name { get; }

		//Only declaration n No body
		public abstract string ShowMessage(string msg);

		//Non abstract methods
		public string Common_NonAbstactMethod()
		{
			return "Hello!";
		}

		//Non abstract static method --> which will be called using the class name
		public static void Print()
		{

		}

		//Static methods with abstract keyword is not legal
		//public static abstract void PrintMsg();
		

	}

	public class ANonAbstract_ChildClass : Abstract_ParentClass
	{

		public ANonAbstract_ChildClass()
		{
			Console.WriteLine("ANonAbstractClass ctor");
		}

		#region Override_Abstract_Methods_&_Property

		public override string Name { get { return "..."; } }

		public override string ShowMessage(string msg)
		{
			return "Msg";
		}

		#endregion

		public void Calculate() 
		{		
		
		}
	}



}
