﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public delegate void demoDelegate(string msg);
	public class MulticastDelegate
	{
		public static void DemoMulticastDelegate()
		{
			demoDelegate obj1 = ClassOne.SendSMS;

			demoDelegate obj2 = ClassTwo.SendEmail;

			demoDelegate obj3 = ClassTwo.MethodThree;

			demoDelegate objMultiCast = obj1 + obj2;

			//objMultiCast = objMultiCast + obj3; //===> Longway
			objMultiCast += obj3; //===> shorthand


			//Calling a Multicast Delegate
			objMultiCast("Hello!!!!");
			//or
			//objMultiCast.Invoke("Hello!!!!");


			objMultiCast = objMultiCast - obj1;

			objMultiCast("Hello!!!!");


		}


	}

	public class ClassOne
	{
		public static void SendSMS(string message)
		{
			Console.WriteLine("Called ClassOne.MethodB() with parameter: " + message);
		}
	}
	public class ClassTwo
	{
		public static void SendEmail(string message)
		{
			Console.WriteLine("Called ClassTwo.MethodB() with parameter: " + message);
		}

		public static void MethodThree(string message)
		{
			Console.WriteLine("Called ClassTwo.MethodB() with parameter: " + message);
		}
	}
}
