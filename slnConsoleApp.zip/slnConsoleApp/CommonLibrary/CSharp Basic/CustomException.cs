﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	#region CustomException

	public class InvalidMobileNumber : Exception
	{
		public InvalidMobileNumber()
		{

		}

		public InvalidMobileNumber(string msg) : base(msg)
		{

		}
	}

	#endregion


	#region CustomExceptionImplementation


	public class CustomExceptionImplementation
	{

		public static void CheckMobileNumber(string strMobileNumber)
		{
			try
			{
				if (strMobileNumber.Length < 10)
					throw new InvalidMobileNumber("Please enter 10 digit number.");			
				else if (strMobileNumber.Contains("+"))
					throw new InvalidMobileNumber("Please do not use + symbol in mobile number");

				Console.WriteLine(strMobileNumber);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}

	}

	#endregion






}
