﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	//To learn about init initilizer plz see Misc.cs file in ConsoleApp_New


	public class Student
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }

		public Student()
		{

		}

		public Student(int Id)
		{
			this.Id = Id;
		}

	}



}
