﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	public delegate void area_perimeter_Delegate(double param1, double param2 = 0, double param3 = 0);

	public class UseOfDelegate
	{

		public static void DemoDelegateUse(string shape, double param1, double param2 = 0, double param3 = 0)
		{
			area_perimeter_Delegate objArea = null;
			area_perimeter_Delegate objPerimeter = null;
			switch (shape)
			{

				case "Circle":
					{
						objArea = Area.AreaOfCircle;
						objPerimeter = Perimeter.PerimeterOfCircle;
					};
					break;
				case "Square":
					{
						objArea = Area.AreaOfSquare;
						objPerimeter = Perimeter.PerimeterOfSquare;
					}
					break;
				case "Triangle":
					{
						objArea = Area.AreaOfTriangle;
						objPerimeter = Perimeter.PerimeterOfTriangle;
					}
					break;
				case "Rectangle":
					{
						objArea = Area.AreaOfRectangle;
						objPerimeter = Perimeter.PerimeterOfRectangle;
					}
					break;
				default:
					{
						Console.WriteLine("Sorry we can't calculate the area of {0}", shape);
					}
					break;
			}

			area_perimeter_Delegate area_perimeter_Both_Delegate = objArea + objPerimeter;
			//CalculateAreaOfShape(area_perimeter_Both_Delegate, param1, param2, param3);
			area_perimeter_Both_Delegate(param1, param2, param3);
		}

		/// <summary>
		/// Passing A function as a parameter with the help of a Delegate
		/// </summary>
		//public static void CalculateAreaOfShape(area_perimeter_Delegate delegateOne, double param1, double param2 = 0, double param3 = 0)
		//{
		//	delegateOne(param1, param2, param3);
		//}

	}


	public class Area
	{

		public static void AreaOfCircle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Area is {0}", (3.14 * Math.Pow(param1, 2)));
		}

		public static void AreaOfSquare(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Area is {0}", Math.Pow(param1, 2));
		}

		public static void AreaOfTriangle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Area is {0}", ((param1 * param2) / 2));
		}

		public static void AreaOfRectangle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Area is {0}", (param1 * param2));
		}


	}

	public class Perimeter
	{
		public static void PerimeterOfCircle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Perimeter is {0}", 2 * 3.14 * param1);
		}

		public static void PerimeterOfSquare(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Perimeter is {0}", (4 * param1));
		}

		public static void PerimeterOfTriangle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Perimeter is {0}", (param1 + param2 + param3));
		}

		public static void PerimeterOfRectangle(double param1, double param2 = 0, double param3 = 0)
		{
			Console.WriteLine("Perimeter is {0}", (2 * (param1 + param2)));
		}
	}
}
