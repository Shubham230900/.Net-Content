﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Readonly_VS_Constant
	{
		//Compile Time Constant - const keyword
		public const decimal gravity = (decimal)9.8;
		public const decimal pi = (decimal)3.14;
		public const string str = "hum to nhi padhenge!";

		public readonly Readonly_VS_Constant obj = new Readonly_VS_Constant();

		//below will give error
		//public const int intValue;	//It is mandatory to assign a value to the const while declaring it.

		public void TryToUpdateConstantValue()
		{
			//gravity = (decimal)7.9;  //<------- gives error coz value can't be assigned to a constant
			//pi = (decimal)567;
			//str = "are padh lo bhai!";
		}

		//Runtime Time Constant

		public readonly int Time = 10;
		public readonly decimal Salary;		//<---- does not require any initial value
		public readonly string msg = "hum to nahi padhenge";

		public void TryToUpdateReadonlyValue()
		{
			//Time = 5;		//<------- gives error coz value can only be assigned or reassigned to readonly in the class construtor
			//Salary = 567;
			//msg = "padh lo!";
		}

		public Readonly_VS_Constant()			//Constructor
		{
			Console.WriteLine(gravity);
			//We can set/update the values of readonly.
			Time = 5;
			Salary = 567;
			msg = "padh lo, nahi to Neha ma'am ko bol dunga!";
			obj = new Readonly_VS_Constant();
		}

	}
}
