﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace CommonLibrary.CSharp_Basic
{
	//Relationship with Classes -> Association and Composition and Aggregation

	#region InterfaceBasic


	//Pure abstract class
	//-> all methods are abstract in nature (only signature and no body)
	//-> can't create instance of the interface
	//-> all methods has to be implemented in the child/derived class. ( c# 11  or .NET 6 onwards you can create (default) functions with body in interface )
	//-> should not use public/private/protected in the methods which are inside an interface (This statement is true till C# 8.0)
	//-> Interface help us to achieve multiple inheritance
	public interface ITestOne
	{
		void Show(string str);

		void Print(string str);

		//Default methods are supported on C# 8.0 or greater
		//void DefaultMethod()
		//{
		//	Console.WriteLine("Hiii");
		//}
	}

	public interface ITestTwo
	{
		void Show(string str);

		void Print(string str);

		void Delete(int Id);
	}

	public class ParentTestOne
	{
		public int Id;

		public void MethodOne()
		{

		}

		public void Show(string str)
		{
			Console.WriteLine(str);
		}
	}

	public class ParentTestTwo
	{
		public void Show(string str)
		{
			Console.WriteLine(str);
		}

		public void MethodTwo()
		{

		}
	}

	//Multiple inheritance is not allowed in C#. That's y we can't inherite "ParentTestTwo" in the Test class
	//Also in other words a class can't have multiple base/parent/super class but can inherit multiple interfaces
	public class Test : ParentTestOne, ITestOne, ITestTwo
	{

		#region These-Methods-Are-Considered-To-Be-New-Mthods-Of-Test-Class-Coz-They-Do-NotMatch-Interface-Method-Signature
		public void Show()
		{
			Console.WriteLine("");
		}

		public void Print()
		{
			Console.WriteLine("");
		}
		#endregion

		public new void Show(string str)
		{
			Console.WriteLine(str);
		}

		public void Print(string str)
		{
			Console.WriteLine(str);
		}

		public void Delete(int Id)
		{
			Console.WriteLine("Id is deleted");
		}
	}

	#endregion


	#region ExplicitCalling

	public interface IDemo
	{
		void Print(string msg);

		void Show(string str);
	}

	public class Demo : IDemo
	{
		public void Print(string msg)
		{
			Console.WriteLine(msg);
		}

		//Explicit interface method
		//should not be decorated with any access specifier
		void IDemo.Show(string str)
		{
			Console.WriteLine(str);
		}
	}

	#endregion


	#region UseOfInterfaceToAchieveAbstraction

	internal interface IMySecret
	{
		void Print(string msg);
		void TopSecret();
	}

	public class MyClass : IMySecret
	{
		public void Print(string msg)
		{
			Console.WriteLine("Hello!");
		}

		void IMySecret.TopSecret()
		{
			Console.WriteLine("Show my Secret!");
		}

	}


	public class MyFamily
	{

		public void RunFamily()
		{

			MyClass myClass = new MyClass();
			myClass.Print("Hello!");
			//myClass.TopSecret();

			//Not accesible here
			IMySecret mySecret = new MyClass();
			mySecret.TopSecret();

		}


	}


	#endregion


}
