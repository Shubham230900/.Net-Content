﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	internal class ToDo_InBuildDelegate
	{

		//LINQ and Lambda Function

		#region Action-Func-Predicate

		#endregion


	}
}
