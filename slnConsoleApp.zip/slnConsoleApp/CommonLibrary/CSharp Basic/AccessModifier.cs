﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	//---:Important Note:---//
	//A class directly inside a Namespace can not have Private / Protected / Protected Internal / Private Protected 
	//private class AccessModifier
	//{
	////Not a valid class
	//}

	//Access Specifier
	//public -> can accessed anywhere
	//internal -> can be accessed anywhere inside the same project
	//private -> can only be accessed with in the class in which it is declared
	//protected -> can be accessed by the same class and also by the derived class
	//protected internal -> same as above but also only in the same class.
	//private protected -> to dooooooooooo..........


	//---:Important Note:---//
	//By default a class inside the namespace is Internal if no access modifier is written.
	class ClassWithoutAnyAccessSpecifier
	{
		//The default access specifier of this class is Internal
	}

	internal class ClassWhichIsInternal
	{
		public class APublicClass
		{
			//This class can not be accessed outside this project as its parent class is INTERNAL
		}
	}

	public class ClassWhichIsPublic
	{

	}


	public class APublicClassToDemoOtherAccessModifier	//<----- This will act as an OUTER Class
	{

		public void Method()
		{
			AClassWithoutAnyAccessSpecifier obj = new AClassWithoutAnyAccessSpecifier();

			//obj.AClassWithoutAnyAccessSpecifier_Method_Private();
			obj.AClassWithoutAnyAccessSpecifier_Method_Public();
			obj.AClassWithoutAnyAccessSpecifier_Method_Internal();
			//obj.Method_Without_AccessSpecifire(); //<---- private method can't be accessed outside of the class
		}


		class AClassWithoutAnyAccessSpecifier
		{
			private void AClassWithoutAnyAccessSpecifier_Method_Private()
			{

			}

			public void AClassWithoutAnyAccessSpecifier_Method_Public()
			{
				//Access Internal
				AClassWithoutAnyAccessSpecifier_Method_Private();
			}

			internal void AClassWithoutAnyAccessSpecifier_Method_Internal()
			{
				Method_Without_AccessSpecifire();
			}

			void Method_Without_AccessSpecifire()	//<------- this will act as a private member to this class
			{

			}
		}

		internal class AnInternalClass 
		{ 

		}

		public class APublicClass
		{

		}

		private class APrivateClass
		{

		}

		protected class AProtectedClass 
		{ 
		
		}

		protected internal class AProtectedInternalClass
		{

		}

}








}
