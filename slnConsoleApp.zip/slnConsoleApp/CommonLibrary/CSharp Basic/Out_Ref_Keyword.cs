﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Out_Ref_Keyword
	{

		static Out_Ref_Keyword()
		{

		}

		//Current Output
		//1-2
		//1-2

		//Expected Output
		//1-2
		//2-1

		public void Demo()
		{
			int a = 1;
			int b = 2;

			int total;

			Console.WriteLine(a + "-" + b);

			Swap(ref a, ref b, out total);

			Console.WriteLine(a + "-" + b + "-" + total);


			int sum;
			int difference;
			decimal average;
			int multiply;

			int returnedValue = Calculate(a, b, out sum, out difference, out average, out multiply);

			sum = Sum(a, b);

			Console.WriteLine("Sum - " + sum);
			Console.WriteLine("Difference - " + difference);
			Console.WriteLine("Average - " + average);
			Console.WriteLine("Multiply - " + multiply);




		}

		public void Swap(ref int a, ref int b, out int total)
		{
			int c = b;
			b = a;
			a = c;

			total = a + b;
			//Out param needs to be assigned a value before returning to the caller function. 			
		}


		public int Calculate(int a, int b, out int sum, out int difference, out decimal average, out int multiply)
		{
			sum = a + b;
			difference = b - a;
			average = (a + b) / 2;
			multiply = a * b;

			return 10000;
		}

		public int Sum(int a, int b)
		{
			return a + b;
		}

		public int Multiply(int a, int b)
		{
			return a * b;
		}


		//int a = 1;
		//int b = 2;

		//Console.WriteLine();



		//Ref Keyword
		//Need initial value

		//Out Keyword
		//Does not require initialization 


	}
}
