﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//Value Type
	public class Enum
	{
		public enum DaysOfWeek
		{
			Monday = 1,
			Tuesday = 2,
			Wednesday = 3,
			Thursday = 4,
			Friday = 5,
			Saturday = 6,
			Sunday = 7
		}

		public enum Gender
		{
			Male = 1,
			Female = 2,
			Others = 3
		}

		public enum MyEnum
		{
			Abc = 1,
			Abcd = 2,
			ABCDE = 3,
			ABCDEE,
			ABCDE5 = 3,
			ABCDE2 = 30,
			ABCDE7 = 3,
			ABCDE9 = 3
		}

		public enum Names
		{
			Title, FirstName, LastName
		}

		public static void Demo_Enum()
		{

			Console.WriteLine(MyEnum.Abc);
			Console.WriteLine(MyEnum.ABCDEE);
			Console.WriteLine(MyEnum.ABCDE5);

			Console.WriteLine((int)MyEnum.Abc);
			Console.WriteLine((int)MyEnum.ABCDEE);
			Console.WriteLine((int)MyEnum.ABCDE5);

			//Invalid
			//Console.WriteLine((string)MyEnum.Abc);
			//Console.WriteLine((string)MyEnum.ABCDEE);
			//Console.WriteLine((string)MyEnum.ABCDE5);

			CreateStudentRecord("Ankit", 34, Gender.Male);


		}


		public static void CreateStudentRecord(string name, int age, Gender gender)
		{
			Console.WriteLine(gender);
		}


	}
}
