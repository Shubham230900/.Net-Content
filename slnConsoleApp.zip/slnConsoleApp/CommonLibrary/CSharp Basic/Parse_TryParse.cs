﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//7737703521
	//double seven three double seven
	//seven seven three seven.......
	public class Parse_TryParse
	{
		public static void Demo_Parse_TryParse()
		{
			try
			{

				int yu = 3456789;

				string yuString = yu.ToString(); //--> Does not handle null value and will throw error
				yuString = Convert.ToString(yu);


				string str = "100";

				int a = 0;

				#region int.Parse

				//a = (int)str;	//This type of type casting is not allowed

				a = Convert.ToInt32(str);

				a = Convert.ToInt32(null);      //This will handle null argument and will not throw error and will set default value to a which is ZERO.

				//a = int.Parse(null);			//Extension Method
				//a = int.Parse("10,000");        //Extension Method
				//a = int.Parse("100000000000000000000000000000000000000");        //Extension Method

				a = int.Parse(str);

				//-> error with format exception
				//a = int.Parse("4.32463");

				var floatingValue = float.Parse("1,004.32463");

				var doubleValue = double.Parse("1,004");

				//Format Exception
				//var longValue = long.Parse("1,004.456");

				//Format Exception
				//var longValue = long.Parse("1004.456");

				//Format Exception 
				//var longValue = long.Parse("1,004");


				var decimalValue = decimal.Parse("1,000.33");

				decimal salary = 345678.4567M;

				var decimalValueTwo = decimal.Parse("345,678.4567");

				#endregion


				#region int.TryParse

				//var intValue = Convert.ToInt32("xgfhfhigfkfghihigc");

				int result;
				bool IsIntegerValue = int.TryParse("xgfhfhigfkfghihigc", out result);
				if (IsIntegerValue)
				{
					Console.WriteLine("Yay! Passed string is an Integer value and Result = " + result);
				}
				else
				{
					Console.WriteLine("Oops! Passed string is not an Integer value and Result = " + result);
				}

				#endregion


				#region DateTime Parse & TryParse

				var data = "07-Mar-2009";

				DateTime date = DateTime.Now; //get current date and time of the server.

				date = DateTime.Parse(data);

				DateTime resultDate;
				bool IsDateTime = DateTime.TryParse(data, out resultDate);			

				#endregion


				#region CustomMethodToCheckIfThePassedValueIsIntergerOrNot

				var res = 0;
				bool IsInt = IsInterger("100000000", out res);

				#endregion

			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

		}

		public static bool IsInterger(string str, out int result)
		{
			try
			{
				int a = int.Parse(str);
				result = a;
				return true;
			}
			catch (Exception ex)
			{
				result = 0;
				return false;
			}
		}

	}
}
