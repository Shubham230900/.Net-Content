﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	internal class Misc
	{

		#region Misc

		//Not Allowed
		//Below line will not work as statement is not wrapped around by a Method or a function.
		//Console.WriteLine("Hello! World.");

		//for(int i = 1; i<=10; i++)
		//{
		//Console.WriteLine(i);
		//}


		//Declaring variables inside the class directly is also allowed -> Global Variable
		int a = 10;
		int b = 20;


		//Defining an interface inside a class is also allowed.
		public interface ITest
		{

		}


		//Defining another class inside a class is also allowed
		public class Test
		{

		}


		//Const is also allowed
		public Misc()
		{

		}

		//Also allowed to define properties directly inside the class.
		public string Name { get; set; }

		//Allowed
		public void Show()
		{
			//This is working as it is a part of a function or a method
			Console.WriteLine("Hello! World.");
		}

		#endregion

	}
}
