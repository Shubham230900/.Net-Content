﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;

namespace CommonLibrary.CSharp_Basic
{
	public class Class_Object
	{
		

		//Long way of defining a property
		private int _myProperty; // <----- This is a private field
		public int MyProperty	// <----- Publically accessible via property
		{
			get { return _myProperty; }
			set { _myProperty = value; }
		}

		//Short way of defining a property
		//A property adds a layer of abstraction over a given field.
		//public int MyProperty { get; set; }




		public string FirstName;
		public string LastName;
		//public string FullName = FirstName + " " + LastName;

		private string _fullName;
        public string FullName 
		{ 
			get { return this.FirstName + " " + this.LastName; } 
			set { _fullName = "Mr. " + value; } 
		}

        //shortcut for property ------> prop + press Enter
        public bool IsActive { get; set; }

        //property
        public int ID { get; set; }
		//property
		public string Name { get; set; }

		public string Name_Not_To_Be_Set { get; }


		//Global Variable/field
		public int a = 199;
		public string str = "Hi Hello Kemcho";

		//private Global Variable
		int privateGlobalVariable = 20000;


		//Important Notes:
		#region Case-Sensitive-And-InSensitive

		//C# is case-sensitive
		//All of the below variables are different from each other and hold value in different memory location
		//int value = 10;
		//int VALUE = 30;
		//int Value = 50;
		//int ValuE = 80;

		//Below all are equal in SQL as it is a Case Insensitive language
		//SELECT * FROM TABLENAME
		//select * from tablename
		//Select * From TableName
		
		#endregion

		static Class_Object()
		{
			//Static ctor will not have any access modifier
			//Static ctor will only be called once when the first object of that class is created.
			//Static ctor will always be called first when instance is created, even before Default ctor
			//Static ctor will be called by the CLR -> Common Language Runtime when the first instance of the class is created.

			Console.WriteLine("Static ctor is called");
		}

		//shortcut to create constructor -----> ctor + press Enter
		public Class_Object()
		{
			//Default Constructor ---> Coz it has no parameters
			//This will always runs when a new instance of this class or any child class is created

			Console.WriteLine("Default ctor is called");
		}

		//ToDo: Private Constructor



		//Parametrize Ctor
		public Class_Object(int a)
		{
			Console.WriteLine("Parametrize 1 ctor is called");
		}

		public Class_Object(string str)
		{
			Console.WriteLine("Parametrize 2 ctor is called");
		}

		public Class_Object(int a, string str)
		{
			Console.WriteLine("Parametrize 3 ctor is called");
		}



		//Member function of class "Class_Object"
		public void DemoClassObjectMethod_One()
		{
			Console.WriteLine(_fullName);

			//get private global variable is allowed in the same class
			Console.WriteLine(privateGlobalVariable);
			//setting the private globale variable is also alloed in the same class
			privateGlobalVariable = 780;

			a = 100000;
			str = "Zellooooooooo";
			Name = "This is DemoClassObjectMethod";
			ID = 100;
			Console.WriteLine("DemoClassObject is called");
		}

		//Member function of class "Class_Object"
		public void DemoClassObjectMethod_Two()
		{

			//get private global variable is allowed in the same class
			Console.WriteLine(privateGlobalVariable);
			//setting the private globale variable is also alloed in the same class
			privateGlobalVariable = 780;

			a = 500000;
			str = "Hellooooooooooooooooooo";
			Name = "This is DemoClassObjectMethod";
			ID = 10000;
			Console.WriteLine("DemoClassObject is called");
		}


		//Important Notes:
		//Destructor
		//CLR will call the Garbage Collector and the Garbage Collector will call the destructor
		//We should never write/create a destructor in the class
		~Class_Object() 		
		{ 
		//
		}

		#region Inheritance

		public class Parent
		{

			public int Id { get; set; }

			public Parent() //static ctor / private ctor / which ctor will be called first - static
			{ 
				Console.WriteLine("Parent Constructor");
			}

			public void ParentMethod()
			{
				Console.WriteLine("ParentMethod");
			}

			public void CommonMethod()
			{
				Console.WriteLine("CommonMethod from Parent class");
			}

		}

		public class Child : Parent
		{

			public Child()
			{
				Console.WriteLine("Child Constructor");
			}

			public void ChildMethod()
			{
				Console.WriteLine("ChildMethod");
			}

			public void CommonMethod()
			{
				Console.WriteLine("CommonMethod from Child class");
			}

		}

		#endregion

	}
}
