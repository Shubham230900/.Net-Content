﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Class_Indexer
	{

		private string[] nameArr = new string[10];

		//Indexer syntax
		public string this[int i]
		{
			get 
			{
				return nameArr[i];
			}
			set 
			{
				nameArr[i] = value;			
			}
		}

		public string[] arr;

	}
}
