﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class AnonymousType
	{
		public static void DemoAnonymousType()
		{
			//Types are defined
			int a = 1;
			string str = "Hello";

			int[] arr = new int[] { 1, 2, 3 };

			//AnonymousType

			var obj = new
			{
				Id = 1,
				Name = "Ankit",
				Address = "Jaipur",
				Salary = 1234567.56M
			};

			Console.WriteLine("Id: {0} Name: {1} Address: {2} Salary: {3}", obj.Id, obj.Name, obj.Address, obj.Salary);




		}

	}
}
