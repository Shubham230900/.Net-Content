﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ExtensionMethods;

//Method to check given integer value is greater then another value

namespace CommonLibrary.CSharp_Basic
{
	public class ToDo_ExtensionMethod
	{
		public static void DemoExtensionMethod()
		{

			int initialValue = 100;
			int compareWith = 50;

			#region Without-Extension-Methods

			if (IsGreaterThan(initialValue, compareWith))
			{
				Console.WriteLine("Yes {0} is greater than {1}", initialValue, compareWith);
			}
			else
			{
				Console.WriteLine("Yes {0} is smaller than {1}", initialValue, compareWith);
			}

			#endregion

			#region With-Extension-Methods

			if (initialValue.IsGreaterThan(compareWith))    //Extension method is used here
			{
				Console.WriteLine("Yes {0} is greater than {1}", initialValue, compareWith);
			}
			else
			{
				Console.WriteLine("Yes {0} is smaller than {1}", initialValue, compareWith);
			}

			#endregion

			#region String-Extension-Method

			string str = "ab_fgh57689cabc987654.io";

			Console.WriteLine("{0} is an email address: {1}", str, str.IsEmailAddress());

			str = "7737703521";
			Console.WriteLine("{0} is an mobile number: {1}", str, str.IsMobileNumber());

			#endregion

		}



		public static bool IsGreaterThan(int val1, int val2)
		{
			return val1 > val2;
		}


	}
}


namespace ExtensionMethods
{

	public static class IntExtensions
	{
		public static bool IsGreaterThan(this int val1, int val2)
		{
			return val1 > val2;
		}
	}

	public static class StringExtensions
	{
		public static bool IsEmailAddress(this string str)
		{
			//----@---.--- //here - denotes alphanumeric + special symbols ( _ underscore)

			//The process of validating a string against a set of rules is called pattern matching

			//Regular Expression are used for pattern matching
			//Test your regular expression here: https://regex101.com/		
			return Regex.IsMatch(str, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
		}


		public static bool IsMobileNumber(this string str)
		{
			//Test your regular expression here: https://regex101.com/
			return Regex.IsMatch(str, @"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$
");
		}

	}


}