﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//class -> reference type
	public class LocationClass
	{
		public int x;
		public int y;
	}

	interface ITest
	{
		void Show();
	}

	struct Loc
	{
		public string Name;
	}

	//struct -> value type
	//Don't use abstract, sealed, virtual or protected
	//Struct can implement interfaces
	//We can't inherit struct or class in a Sturct
	//Sturct can't have parameterless ctor
	// --> Struct is faster than a Class -> use to store simple data
	struct Location : ITest
	{
		public int x;
		public int y;

		public void JumpTenPoints()
		{
			this.x = this.x + 10;
			this.y = this.y + 10;
		}

		//Parameterless CTOR -- Is not available in C# 7.3
		//public Location()
		//{
		//	this.x = 0;
		//	this.y = 0;
		//}

		//Constructor
		public Location(int x, int y)
		{
			this.x = x;
			this.y = y;
		}

		public void Show()
		{
			Console.WriteLine("Show");
		}

	}

	public class DemoStruct
	{
		public static void DemoStucture()
		{
			//Class is a Reference Type
			LocationClass obj = new LocationClass();
			obj.x = 10;
			obj.y = 20;

			//Struct is a Value Type
			Location loc = new Location();
			loc.x = 10;
			loc.y = 20;

			// --------------Another way of initializing the Struct
			Location locc;
			//var value = locc.x; // Compile time error as locc is not initiated with values.

			locc.x = 100;
			locc.y = 200;
			var value = locc.x; //Now value is assigned so no error

			// --------------Another way of initializing the Struct

			Location loccc = new Location(30, 80); //Initialize using parameterized ctor
			
			loccc.JumpTenPoints();
		}

	}


}
