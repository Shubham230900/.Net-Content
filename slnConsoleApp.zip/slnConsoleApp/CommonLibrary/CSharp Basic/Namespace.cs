﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Red
{

	public class MyClass    //Red.MyClass
	{

	}

}


namespace Red
{
	//public class MyClass	//Red.MyClass
	//{
	//This will give you error as it has already declared above
	//}

	public class MyClassTwo //----> Red.MyClassTwo
	{
		public MyClassTwo()
		{
			//ctor
		}
	}

	namespace Red  /// Red.Red ---> Parent namespace 
	{
		public class MyClass        //Red.Red.MyClass
		{
			//This class will not give us compile time error as the name 
		}
		public class MyClassTwo    //Red.Red.MyClassTwo
		{
			public MyClassTwo()
			{
				//ctor
			}

		}
	}

}
