﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic.Inheritance
{
	public class ParentClass
	{
		static ParentClass()
		{
			Console.WriteLine("ParentClass's Static ctor is called");
		}

		public ParentClass()
		{
			Console.WriteLine("ParentClass's Default ctor is called");
		}
	}

	public class ChildClass : ParentClass
	{
		static ChildClass()
		{
			Console.WriteLine("ChildClass's Static ctor is called");
		}

		public ChildClass()
		{
			Console.WriteLine("ChildClass's Default ctor is called");
		}
	}

}
