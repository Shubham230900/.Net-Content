﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{

	//Garbage Collection, Object Graph with Genration 0, Generation 1
	//and Generation2, System.GC Members MaxGeneration,
	//GC.Collect(), GC.WaitForPendingFinalizers(), GC.SupressFinalize()
	internal class ToDo_GarbageCollection
	{
	}
}
