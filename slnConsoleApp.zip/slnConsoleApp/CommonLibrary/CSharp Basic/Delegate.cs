﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//function pointers
	//Also by using delegates we can pass a function/method as a parameter to a different function/method
	public delegate void ABCDelegate(string msg); //	---------> declaring a delegate

	public delegate int ABCDelegateTwo(string msg); //	---------> declaring a delegate

	public class ToDo_Delegate
	{
		public delegate void ShowDelegate();

		public static string RetrunString()
		{
			return "Hello!";
		}

		public static void Method(int a, int b, string str, ShowDelegate show)
		{
			Console.WriteLine(str);

			show.Invoke(); // or show();
		}


		public static void DemoDelegate()
		{
			ShowDelegate show = ClassA.Show;
			Method(1, 2, RetrunString(), show);

			ClassA obj = new ClassA();
			//obj.Show();

			ShowDelegate delShow = ClassA.Show;
			delShow();
			delShow.Invoke();

			//Calling the function
			ClassA.MethodA("Hello!!");

			//Pointing to a function using Delegate

			//We are assigning the method defination (pointing towards) of "MethodA" to a local variable "del"
			//which is of type "ABCDelegate"
			ABCDelegate del = ClassA.MethodA; //here "del" is pointing towards "MethodA"
			del("Hello World");

			ABCDelegateTwo delTwo = ClassA.MethodTwo;
			var result = delTwo("Hello!!");

			del = ClassB.MethodB;
			del("Hello World");

			del = (string msg) => Console.WriteLine("Called lambda expression: " + msg);
			del("Hello World");


			//Shorthand
			del("A-B-C");
			//Or
			//Execute the method using Invoke
			del.Invoke("X-Y-Z");
		}
	}

	public class ClassA
	{

		public static void Show()
		{
			Console.WriteLine("Show!!");
		}

		public static void MethodA(string message)
		{
			Console.WriteLine("Called ClassA.MethodA() with parameter: " + message);
		}

		public static int MethodTwo(string message)
		{
			Console.WriteLine("Called ClassA.MethodA() with parameter: " + message);
			return 0;
		}
	}

	public class ClassB
	{
		public static void MethodB(string message)
		{
			Console.WriteLine("Called ClassB.MethodB() with parameter: " + message);
		}
	}






}
