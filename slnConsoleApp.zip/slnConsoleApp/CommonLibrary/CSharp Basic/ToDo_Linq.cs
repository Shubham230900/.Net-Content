﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	//LINQ Basics, LINQ Lambda expressions, Query Comprehension
	//Syntax, LINQ Standard Query Operators, extension Methods,
	//Anonymous Function
	internal class ToDo_Linq
	{
	}
}
