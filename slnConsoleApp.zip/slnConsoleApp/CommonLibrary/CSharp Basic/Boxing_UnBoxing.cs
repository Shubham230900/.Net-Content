﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Boxing_UnBoxing
	{

		public static void Demo_Boxing_UnBoxing()
		{
			int a = 10; //int a is basically value type ---> value of int a is stored on stack only.			

			var aa = 100;
			aa = 1000;

			//Exception
			//aa = "";	//"var" is strongly typed and can't be assigned a different type value once it is initiaized (initiaized apart from "Object")

			//Boxing				-> Conversion of value type to reference type
			object obj = a;         //Now the value of obj is stored on heap and reference on stack.


			//Unboxing				-> Conversion of reference type to value type with the help of type casting
			int b = (int)obj;


			//Important
			string str = "fghjgfgkhljhg";
			obj = str;              //"object" type can be assigned any type of value and at any given time,
									//even if they are holding any different data type value previously.

			var data = obj;
			data = 100;
			//data = "jfhkgjjghj";

			int abc = (int)data;

			//***Important Note:
			//string n object both will behave same when passed to a different function and updated inside that function
			//their value will not be updated in the main/caller function unless we are passing them using ref/out parameter. 

			object o = 1234567;
			Console.WriteLine(o);
			//Use of TypeOf
			Method(o);
			Console.WriteLine(o);

			string strOne = "ABC";
			MethodString(strOne);
			Console.WriteLine(strOne);

		}

		public static void MethodString(string str)
		{
			str = "XYZ";
		}

		public static void Method(object o)
		{
			//Check if the object is containing a integer value
			if (o.GetType() == typeof(int))
			{
				Console.WriteLine("Parameter is of Int Type");
			}
			o = 1000;
		}

	}
}
