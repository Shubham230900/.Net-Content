﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary.CSharp_Basic
{
	public class Stack_N_Queue
	{

		public static void Demo_Stack()
		{
			//LIFO
			Stack<int> intStack = new Stack<int>();

			//Push
			intStack.Push(1);
			intStack.Push(2);
			intStack.Push(3);
			intStack.Push(4);
			intStack.Push(5);

			//Indexers ---> stack does not support Indexers.
			//var data = intStack[1];

			foreach (var item in intStack)
			{
				Console.WriteLine(item);
			}

			int[] arr = new int[] { 124, 235, 34, 645, 76, 58, 68, 5432, 9 };
			Stack<int> stack = new Stack<int>(arr);

			foreach (var item in stack)
			{
				Console.WriteLine(item);
			}

			//Peek -> Returns the lastly added value but does not remove it.
			foreach (var item in intStack)
			{
				Console.WriteLine(intStack.Peek());
				Console.WriteLine(intStack.Peek());
				Console.WriteLine(intStack.Peek());
			}

			//Pop -> Return last element and remove it from stack.
			Console.WriteLine(intStack.Pop());
			Console.WriteLine(intStack.Pop());

			//Contains
			var hasValue = stack.Contains(645);
			if (stack.Contains(76))
			{
				Console.WriteLine("Number Exists");
			}

			//Clear
			stack.Clear();
			intStack.Clear();

		}

		public static void Demo_Queue()
		{
			//FIFO
			Queue<int> queue = new Queue<int>();

			//Enqueue -> add item
			queue.Enqueue(1);
			queue.Enqueue(2);
			queue.Enqueue(3);
			queue.Enqueue(4);
			queue.Enqueue(5);
			queue.Enqueue(6);

			//Peek -> returns first element/item
			var firstItem = queue.Peek();

			//Contains
			var hasValue = queue.Contains(firstItem);

			//Dequeue -> basically works like POP -> returns the first item and remove it
			while (queue.Count > 0)
				Console.WriteLine(queue.Dequeue());


			//Clear
			queue.Clear();
		}


	}
}
