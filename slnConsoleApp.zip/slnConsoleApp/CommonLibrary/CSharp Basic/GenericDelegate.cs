﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CommonLibrary.CSharp_Basic.GenericDelegate;

namespace CommonLibrary.CSharp_Basic
{
	public class A
	{

	}

	public class GenericDelegate
	{
		//Non-Generic Delegate
		public delegate int addIntDelegate(int param1, int param2);
		public delegate string addStringDelegate(string param1, string param2);

		//Generic Delegate
		public delegate A addGenericDelegate<A>(A param1, A param2);    //where T represents the type of param n return type of the function

		public static void DemoGenericDelegate()
		{
			//Normal Function calling
			Add(2, 7);//9
			Add("Moye", "Moye"); //MoyeMoye

			//Generic Function Calling
			Add<int>(2, 7);//9
			Add<string>("Moye", "Moye"); //MoyeMoye

			//Add<bool>(true, false); //Run time error

			//Non-Generic Delegate assignment
			addIntDelegate intDel = GenericDelegate.Add;
			addStringDelegate stringDel = GenericDelegate.Add;

			//Function calling using Non-Generic Delegate
			intDel(2, 7);
			stringDel("Moye", "Moye");

			//Function calling using Generic Delegate
			addGenericDelegate<int> genericIntDel = GenericDelegate.Add;
			addGenericDelegate<string> genericStringDel = GenericDelegate.Add;

			addGenericDelegate<double> genericDoubleDel = GenericDelegate.Add;

			var val1 = genericIntDel(2, 7);
			var val2 = genericStringDel("Moye", "Moye");
			var val3 = genericDoubleDel(2, 7);

		}

		public static int Add(int a, int b)     //params type and return type all are same --> int
		{
			return a + b;
		}

		public static string Add(string a, string b)    //params type and return type all are same --> string
		{
			return a + b;
		}

		public static double Add(double a, double b)    //params type and return type all are same --> string
		{
			return a + b;
		}


		#region GenericFunction

		public static T Add<T>(T a, T b)    //params type and return type all are same --> int
		{
			try
			{
				//var //dynamic //volatile
				dynamic val1 = a;
				dynamic val2 = b;
				return val1 + val2;
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}


		#endregion


	}
}
