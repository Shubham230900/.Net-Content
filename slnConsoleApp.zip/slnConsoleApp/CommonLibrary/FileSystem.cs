﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CommonLibrary
{
	//CRUD -> Create n Read n Update n Delete
	public class FileSystem
	{

		public static void DemoFileSystem()
		{
			var path = @"C:\Code";
			CreateDirectory(path, "UploadFile");

			//CreateFile(Path.Combine(path, "UploadFile"), "demo.txt");

			//ReadDirectory(Path.Combine(path, "UploadFile"));

			WriteFile(Path.Combine(path, "UploadFile", "demo.txt"), "Hello! World.");

			ReadFile(Path.Combine(path, "UploadFile", "demo.txt"));

			if(File.Exists(Path.Combine(path, "UploadFile", "demo.txt")))
			{
				Console.WriteLine("File Exists!!");
			}

			DeleteDirectory(Path.Combine(path, "UploadFile"), true);



		}


		#region FileFunction		

		public static void CreateFile(string basePath, string fileName)
		{
			string fullPath = Path.Combine(basePath, fileName);   //---> C:\Code\UploadFile
			File.Create(fullPath);
		}

		public static void WriteFile(string filePath, string text)
		{
			File.WriteAllText(filePath, text);		

			File.AppendAllText(filePath,"dhfjgkl;kdhsdtfguhiojpojhgfhxghjhgfdkyfuiuoigufdrugvcgkdfugj.vhcgyutigjvcgkyfugjvcgfgj.kvhjflgjvjflugjvjflgggukkg.gk.gjkgjk.j");

			//FileInfo fileInfo = new FileInfo(filePath);
			//fileInfo.Delete();
		}

		public static void ReadFile(string filePath)
		{
			var data = File.ReadAllText(filePath);
			Console.WriteLine(data);
		}

		#endregion

		#region DirectoryFunction

		public static void CreateDirectory(string basePath, string directoryName)
		{
			//string fullPath = basePath + directoryName;  --> C:\CodeUploadFile
			string fullPath = Path.Combine(basePath, directoryName);   //---> C:\Code\UploadFile
			Directory.CreateDirectory(fullPath);
		}

		public static void ReadDirectory(string directoryPath)
		{
			var data = Directory.GetFiles(directoryPath);
			foreach (var file in data)
			{
				Console.WriteLine(file);
			}
		}

		public static void DeleteDirectory(string directoryPath, bool recursive = false)
		{
			Directory.Delete(directoryPath, recursive);
		}

		#endregion




	}
}
